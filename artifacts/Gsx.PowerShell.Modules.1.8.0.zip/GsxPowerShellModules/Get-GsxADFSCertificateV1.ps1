param (
	[bool] $PowerShellLocal = $false
)

$Output = New-Object Gsx.Robot.PSModel.PSOutput

# Import Module
Import-Module "$pwd\GsxPowerShellModules\Modules\GsxModules.psm1" -Force

$ParametersHashtable = @{}
$UsedParameters = $PSBoundParameters.GetEnumerator()

$UsedParameters.ForEach({$ParametersHashtable.Add($_.Key, $_.Value)})

# Getting Certificates
$CertificatesOutput = Get-GsxADFSCertificateV1 @ParametersHashtable
$Certificates = @(($CertificatesOutput.Certificates | ConvertFrom-Json))
$CommandCode = $CertificatesOutput.CommandCode
$CommandMessage = $CertificatesOutput.CommandMessage

# This object with Property ID set to -1 is the status of the command
$Output.AddResult(-1, $null, $null, $CommandCode, $CommandMessage)

if([bool]$Certificates) {
	foreach ($Certificate in $Certificates) {
		$Output.AddResult(1, $Certificate.Thumbprint, $Certificate.Thumbprint, $CommandCode, $CommandMessage)
		$Output.AddResult(2, $Certificate.Thumbprint, $Certificate.NotAfter,   $CommandCode, $CommandMessage)
		$Output.AddResult(3, $Certificate.Thumbprint, $Certificate.Subject,    $CommandCode, $CommandMessage)
	}
}

# We will exit the PowerShell by returning this exact object
Return($Output)