param (
	[bool] $PowerShellLocal = $false
)

$Output = New-Object Gsx.Robot.PSModel.PSOutput

# Import Module
Import-Module "$pwd\GsxPowerShellModules\Modules\GsxModules.psm1" -Force

$ParametersHashtable = @{}
$UsedParameters = $PSBoundParameters.GetEnumerator()

$UsedParameters.ForEach({$ParametersHashtable.Add($_.Key, $_.Value)})

# Getting ADFS Win events
$ADFSWinEventsOutput = Get-GsxADFSWinEventV1 @ParametersHashtable
$ADFSWinEvents = @(($ADFSWinEventsOutput.ADFSWinEvents | ConvertFrom-Json))
$CommandCode = $ADFSWinEventsOutput.CommandCode
$CommandMessage = $ADFSWinEventsOutput.CommandMessage

# This object with Property ID set to -1 is the status of the command
$Output.AddResult(-1, $null, $null, $CommandCode, $CommandMessage)

if ([bool]$ADFSWinEvents) {
	foreach ($WinEvent in $ADFSWinEvents) {
		$Output.AddResult(1,  $WinEvent.RecordId, $WinEvent.ActivityId,           $CommandCode, $CommandMessage) # String
		$Output.AddResult(2,  $WinEvent.RecordId, $WinEvent.Bookmark,             $CommandCode, $CommandMessage) # String
		$Output.AddResult(3,  $WinEvent.RecordId, $WinEvent.ContainerLog,         $CommandCode, $CommandMessage) # String
		$Output.AddResult(4,  $WinEvent.RecordId, $WinEvent.Id,                   $CommandCode, $CommandMessage) # Int32
		$Output.AddResult(5,  $WinEvent.RecordId, $WinEvent.Keywords,             $CommandCode, $CommandMessage) # Int64
		$Output.AddResult(6,  $WinEvent.RecordId, $WinEvent.KeywordsDisplayNames, $CommandCode, $CommandMessage) # String
		$Output.AddResult(7,  $WinEvent.RecordId, $WinEvent.Level,                $CommandCode, $CommandMessage) # Byte
		$Output.AddResult(8,  $WinEvent.RecordId, $WinEvent.LevelDisplayName,     $CommandCode, $CommandMessage) # String
		$Output.AddResult(9,  $WinEvent.RecordId, $WinEvent.LogName,              $CommandCode, $CommandMessage) # String
		$Output.AddResult(10, $WinEvent.RecordId, $WinEvent.MachineName,          $CommandCode, $CommandMessage) # String
		$Output.AddResult(11, $WinEvent.RecordId, $WinEvent.MatchedQueryIds,      $CommandCode, $CommandMessage) # String
		$Output.AddResult(12, $WinEvent.RecordId, $WinEvent.Message,              $CommandCode, $CommandMessage) # String
		$Output.AddResult(13, $WinEvent.RecordId, $WinEvent.Opcode,               $CommandCode, $CommandMessage) # In16
		$Output.AddResult(14, $WinEvent.RecordId, $WinEvent.OpcodeDisplayName,    $CommandCode, $CommandMessage) # String
		$Output.AddResult(15, $WinEvent.RecordId, $WinEvent.ProcessId,            $CommandCode, $CommandMessage) # Int32
		$Output.AddResult(16, $WinEvent.RecordId, $WinEvent.Properties,           $CommandCode, $CommandMessage) # String
		$Output.AddResult(17, $WinEvent.RecordId, $WinEvent.ProviderId,           $CommandCode, $CommandMessage) # String
		$Output.AddResult(18, $WinEvent.RecordId, $WinEvent.ProviderName,         $CommandCode, $CommandMessage) # String
		$Output.AddResult(19, $WinEvent.RecordId, $WinEvent.Qualifiers,           $CommandCode, $CommandMessage) # Int32
		$Output.AddResult(20, $WinEvent.RecordId, $WinEvent.RecordId,             $CommandCode, $CommandMessage) # Int64
		$Output.AddResult(21, $WinEvent.RecordId, $WinEvent.RelatedActivityId,    $CommandCode, $CommandMessage) # String
		$Output.AddResult(22, $WinEvent.RecordId, $WinEvent.Task,                 $CommandCode, $CommandMessage) # Int32
		$Output.AddResult(23, $WinEvent.RecordId, $WinEvent.TaskDisplayName,      $CommandCode, $CommandMessage) # String
		$Output.AddResult(24, $WinEvent.RecordId, $WinEvent.ThreadId,             $CommandCode, $CommandMessage) # Int32
		$Output.AddResult(25, $WinEvent.RecordId, $WinEvent.TimeCreated,          $CommandCode, $CommandMessage) # DateTime
		$Output.AddResult(26, $WinEvent.RecordId, $WinEvent.UserId,               $CommandCode, $CommandMessage) # String
		$Output.AddResult(27, $WinEvent.RecordId, $WinEvent.Version,              $CommandCode, $CommandMessage) # Byte
	}
}

# We will exit the PowerShell by returning this exact object
Return($Output)