param (
	[bool] $PowerShellLocal = $false
)

$Output = New-Object Gsx.Robot.PSModel.PSOutput

# Import Module
Import-Module "$pwd\GsxPowerShellModules\Modules\GsxModules.psm1" -Force

$ParametersHashtable = @{}
$UsedParameters = $PSBoundParameters.GetEnumerator()

$UsedParameters.ForEach({$ParametersHashtable.Add($_.Key, $_.Value)})

# Getting AD Sync Connectors
$ConnectorsOutput = Get-GsxADSyncConnectorV1 @ParametersHashtable
$Connectors       = @(($ConnectorsOutput.Connectors | ConvertFrom-Json))
$CommandCode      = $ConnectorsOutput.CommandCode
$CommandMessage   = $ConnectorsOutput.CommandMessage

# This object with Property ID set to -1 is the status of the command
$Output.AddResult(-1, $null, $null, $CommandCode, $CommandMessage)

if ([bool]$Connectors) {
	foreach ($Connector in $Connectors) {
		$Output.AddResult(1,  $Connector.Name, $Connector.Name,                 $CommandCode, $CommandMessage) # String
		$Output.AddResult(2,  $Connector.Name, $Connector.ConnectorTypeName,    $CommandCode, $CommandMessage) # String
		$Output.AddResult(3,  $Connector.Name, $Connector.Type,                 $CommandCode, $CommandMessage) # String
		$Output.AddResult(4,  $Connector.Name, $Connector.LastModificationTime, $CommandCode, $CommandMessage) # DateTime
		$Output.AddResult(5,  $Connector.Name, $Connector.ExportAdds,           $CommandCode, $CommandMessage) # Int32
		$Output.AddResult(6,  $Connector.Name, $Connector.ExportUpdates,        $CommandCode, $CommandMessage) # Int32
		$Output.AddResult(7,  $Connector.Name, $Connector.ExportDeletes,        $CommandCode, $CommandMessage) # Int32
		$Output.AddResult(8,  $Connector.Name, $Connector.TotalConnectors,      $CommandCode, $CommandMessage) # Int32
	}
}

# We will exit the PowerShell by returning this exact object
Return($Output)