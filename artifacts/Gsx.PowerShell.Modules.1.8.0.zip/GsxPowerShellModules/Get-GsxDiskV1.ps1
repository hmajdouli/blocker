param (
	[bool] $PowerShellLocal = $false
)

$Output = New-Object Gsx.Robot.PSModel.PSOutput

# Import Module
Import-Module "$pwd\GsxPowerShellModules\Modules\GsxModules.psm1" -Force

$ParametersHashtable = @{}
$UsedParameters = $PSBoundParameters.GetEnumerator()

$UsedParameters.ForEach({$ParametersHashtable.Add($_.Key, $_.Value)})

# Getting disks
$DisksOutput = Get-GsxDiskV1 @ParametersHashtable
$Disks = @(($DisksOutput.Disks | ConvertFrom-Json))
$CommandCode = $DisksOutput.CommandCode
$CommandMessage = $DisksOutput.CommandMessage

# This object with Property ID set to -1 is the status of the command
$Output.AddResult(-1, $null, $null, $CommandCode, $CommandMessage)

if([bool]$Disks) {
	foreach ($Disk in $Disks) {
		$Output.AddResult(1, $Disk.Name, $Disk.Name,                  $CommandCode, $CommandMessage)
		$Output.AddResult(2, $Disk.Name, $Disk.Label,                 $CommandCode, $CommandMessage)
		$Output.AddResult(3, $Disk.Name, $Disk.DriveLetter,           $CommandCode, $CommandMessage)
		$Output.AddResult(4, $Disk.Name, $Disk.FileSystem,            $CommandCode, $CommandMessage)
		$Output.AddResult(5, $Disk.Name, $Disk.TotalSizeInGigaBytes,  $CommandCode, $CommandMessage)
		$Output.AddResult(6, $Disk.Name, $Disk.FreeSpaceInGigaBytes,  $CommandCode, $CommandMessage)
		$Output.AddResult(7, $Disk.Name, $Disk.FreeSpaceInPercentage, $CommandCode, $CommandMessage)
		$Output.AddResult(8, $Disk.Name, $Disk.IsMountPoint,          $CommandCode, $CommandMessage)
	}
}

# We will exit the PowerShell by returning this exact object
Return($Output)