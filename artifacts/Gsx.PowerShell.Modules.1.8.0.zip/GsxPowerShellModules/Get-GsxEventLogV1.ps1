param (
	$LogName,
	$Newest,
	$Index,
	$EntryType,
	$InstanceId,
	$Message,
	$Category,
	$CategoryNumber,
	$Source,
	[bool] $PowerShellLocal = $false
)

$Output = New-Object Gsx.Robot.PSModel.PSOutput

# Import Module
Import-Module "$pwd\GsxPowerShellModules\Modules\GsxModules.psm1" -Force

$ParametersHashtable = @{}
$UsedParameters = $PSBoundParameters.GetEnumerator()

$UsedParameters.ForEach({$ParametersHashtable.Add($_.Key, $_.Value)})

# Getting EventLogs
$EventLogsOutput = Get-GsxEventLogV1 @ParametersHashtable
$EventLogs = @(($EventLogsOutput.Logs | ConvertFrom-Json))
$CommandCode = $EventLogsOutput.CommandCode
$CommandMessage = $EventLogsOutput.CommandMessage

# This object with Property ID set to -1 is the status of the command
$Output.AddResult(-1, $null, $null, $CommandCode, $CommandMessage)

if ([bool]$EventLogs) {
	foreach ($EventLog in $EventLogs) {
		$Output.AddResult(1,  $EventLog.Index, $EventLog.Category,           $CommandCode, $CommandMessage)
		$Output.AddResult(2,  $EventLog.Index, $EventLog.CategoryNumber,     $CommandCode, $CommandMessage)
		$Output.AddResult(3,  $EventLog.Index, $EventLog.Container,          $CommandCode, $CommandMessage)
		$Output.AddResult(4,  $EventLog.Index, $EventLog.Data,               $CommandCode, $CommandMessage)
		$Output.AddResult(5,  $EventLog.Index, $EventLog.EntryType,          $CommandCode, $CommandMessage)
		$Output.AddResult(6,  $EventLog.Index, $EventLog.Index,              $CommandCode, $CommandMessage)
		$Output.AddResult(7,  $EventLog.Index, $EventLog.InstanceId,         $CommandCode, $CommandMessage)
		$Output.AddResult(8,  $EventLog.Index, $EventLog.MachineName,        $CommandCode, $CommandMessage)
		$Output.AddResult(9,  $EventLog.Index, $EventLog.Message,            $CommandCode, $CommandMessage)
		$Output.AddResult(10, $EventLog.Index, $EventLog.ReplacementStrings, $CommandCode, $CommandMessage)
		$Output.AddResult(11, $EventLog.Index, $EventLog.Site,               $CommandCode, $CommandMessage)
		$Output.AddResult(12, $EventLog.Index, $EventLog.Source,             $CommandCode, $CommandMessage)
		$Output.AddResult(13, $EventLog.Index, $EventLog.TimeGenerated,      $CommandCode, $CommandMessage)
		$Output.AddResult(14, $EventLog.Index, $EventLog.TimeWritten,        $CommandCode, $CommandMessage)
		$Output.AddResult(15, $EventLog.Index, $EventLog.UserName,           $CommandCode, $CommandMessage)
		$Output.AddResult(16, $EventLog.Index, $EventLog.EventID,            $CommandCode, $CommandMessage)
	}
}

# We will exit the PowerShell by returning this exact object
Return($Output)