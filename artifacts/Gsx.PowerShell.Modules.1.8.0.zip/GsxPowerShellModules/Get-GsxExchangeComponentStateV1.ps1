<#
		.SYNOPSIS
		This command retrieves Exchange server component states related to the Mailbox and Transport service.

		.DESCRIPTION
		This command retrieves Exchange server component states related to the Mailbox and Transport service.

        .PARAMETER ExchangeServer
        Type: [String]
		Description: Defines the Exchange Server hostname.

		.PARAMETER FilterOutHealthSetNames
        Type: [String[]]
        Default value: @()
		Description: Defines the Health Set Names to filter out from the entire list of Exchange server component states.

		.PARAMETER PowerShellLocal
        Type: [Bool]
        Default value: $false
        Description: Defines whether we use PowerShell locally or in a PSSession.

		.EXAMPLE
		Running the Get-GsxExchangeComponentStateV1 command

            PS> Get-GsxExchangeComponentStateV1 -ExchangeServer 'ex16-a.gsxclients.com'

        .OUTPUTS
		Here is an example of the output:

		PropertyId 	Index                                 Value								CommandCode CommandMessage
		---------- 	-----                                 -----                     		----------- --------------
        1 			ClusterGroupMonitor                   ClusterGroupMonitor               0
        2 			ClusterGroupMonitor                   Unhealthy                         0
        3 			ClusterGroupMonitor                   EX16-A                            0
        4 			ClusterGroupMonitor                   3/5/2020 12:48:05 PM              0
        5 			ClusterGroupMonitor                   3/20/2020 9:40:22 AM              0
        6 			ClusterGroupMonitor                   Clustering                        0
        7 			ClusterGroupMonitor                   ServerResources                   0
        1 			StorageLogicalDriveSpaceMonitor       StorageLogicalDriveSpaceMonitor   0
        2 			StorageLogicalDriveSpaceMonitor       Unhealthy                         0
        3 			StorageLogicalDriveSpaceMonitor       MB03                              0
        4 			StorageLogicalDriveSpaceMonitor       3/4/2020 2:04:20 PM               0
        5 			StorageLogicalDriveSpaceMonitor       3/20/2020 9:33:47 AM              0
        6 			StorageLogicalDriveSpaceMonitor       MailboxSpace                      0
        7 			StorageLogicalDriveSpaceMonitor       ServerResources                   0
        1 			SubmissionQueueLengthMonitor          SubmissionQueueLengthMonitor      0
        2 			SubmissionQueueLengthMonitor          Unknown                           0
        3 			SubmissionQueueLengthMonitor                                            0
        4 			SubmissionQueueLengthMonitor          1/1/0001 1:00:00 AM               0
        5 			SubmissionQueueLengthMonitor          1/1/0001 1:00:00 AM               0
        6 			SubmissionQueueLengthMonitor          HubTransport                      0
        7 			SubmissionQueueLengthMonitor          ServiceComponents                 0

		The output from this command will be an object that has the following properties available:

			| Properties     | Type                       |
			| -------------- | -------------------------- |
			| PropertyId     | Int                        |
			| Index          | String                     |
			| Value          | Depends on the Property Id |
			| CommandCode    | Int                        |
			| CommandMessage | String                     |

		.NOTES
        Property Ids:

			| PropertyId | Value            		| Type     | Description            									|
			| ---------- | ------------------		| -------- | ------------------------------------------------------ 	|
			| 1          | Name         			| String   | Exchange server component state unique name.         		|
			| 2          | AlertValue     			| String   | Exchange server component state alert value.     		 	|
			| 3          | TargetResource           | String   | Exchange server component state target resource.        	|
			| 4          | FirstAlertObservedTime	| DateTime | Exchange server component state first alert observed time. |
			| 5          | LastExecutionTime        | DateTime | Exchange server component state last execution time.     	|
			| 6          | HealthSetName     		| String   | Exchange server component state health set name.     	 	|
			| 7          | HealthGroupName   		| String   | Exchange server component state health group name.   	 	|

#>

param (
	[string] $ExchangeServer,
	[string[]] $FilterOutHealthSetNames = @(),
	[bool] $PowerShellLocal = $false
)

Function New-GsxDefaultOutput($OutputObject, $CommandCode, $CommandMessage){
	$OutputObject.AddResult(1, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(2, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(3, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(4, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(5, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(6, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(7, $null, $null, $CommandCode, $CommandMessage)
}

# Storing current error action preference
$OldErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = 'Stop'

$Output = New-Object Gsx.Robot.PSModel.PSOutput

$CommandParameters = @{
	ScriptBlock  = $null
	ArgumentList = $null
}

if (!$PowerShellLocal) {
	$CommandParameters.Session = Get-PSSession
}

$CommandMessage = $null
$CommandCode = 0

# Getting component states
try{
	$CommandString = "Get-ServerHealth -Server '$ExchangeServer' | Select-Object Name, AlertValue, TargetResource, FirstAlertObservedTime, LastExecutionTime, HealthSetName, HealthGroupName"
	$CommandAsScriptBlock = [Scriptblock]::Create($CommandString)
	$CommandParameters.ScriptBlock = $CommandAsScriptBlock

	Write-Verbose 'Retrieving component state(s)...'
	$ComponentStates = Invoke-Command @CommandParameters

	if( ($null -ne $ComponentStates) -and ($ComponentStates.Count -ne 0) ) {

		$Filter = "`$_.AlertValue.ToString() -ne 'Healthy' -and `$_.AlertValue.ToString() -ne 'Disabled'"
		foreach($FilterOutHealthSetName in $FilterOutHealthSetNames){
			$Filter += " -and `$_.HealthSetName -ne '$FilterOutHealthSetName'"
		}

		$FilterAsScriptBlock = [Scriptblock]::Create($Filter)
		$FilteredComponentStates = $ComponentStates | Where-Object $FilterAsScriptBlock

		if( ($null -ne $FilteredComponentStates) -and ($FilteredComponentStates.Count -ne 0) ){
			foreach ($ComponentState in $FilteredComponentStates) {
				$Output.AddResult(1,  $ComponentState.Name, $ComponentState.Name,                   $CommandCode, $CommandMessage)
				$Output.AddResult(2,  $ComponentState.Name, $ComponentState.AlertValue.ToString(),  $CommandCode, $CommandMessage)
				$Output.AddResult(3,  $ComponentState.Name, $ComponentState.TargetResource,         $CommandCode, $CommandMessage)
				$Output.AddResult(4,  $ComponentState.Name, $ComponentState.FirstAlertObservedTime, $CommandCode, $CommandMessage)
				$Output.AddResult(5,  $ComponentState.Name, $ComponentState.LastExecutionTime,      $CommandCode, $CommandMessage)
				$Output.AddResult(6,  $ComponentState.Name, $ComponentState.HealthSetName,          $CommandCode, $CommandMessage)
				$Output.AddResult(7,  $ComponentState.Name, $ComponentState.HealthGroupName,        $CommandCode, $CommandMessage)
			}
		}
		else{
			New-GsxDefaultOutput -OutputObject $Output -CommandCode $CommandCode -CommandMessage $CommandMessage
		}
	}
	else{
		New-GsxDefaultOutput -OutputObject $Output -CommandCode $CommandCode -CommandMessage $CommandMessage
	}
}
catch{
	$CommandMessage = $_.Exception.Message
	$CommandCode = 1

	New-GsxDefaultOutput -OutputObject $Output -CommandCode $CommandCode -CommandMessage $CommandMessage
}

$ErrorActionPreference = $OldErrorActionPreference

# We will exit the PowerShell by returning this exact object
Return($Output)