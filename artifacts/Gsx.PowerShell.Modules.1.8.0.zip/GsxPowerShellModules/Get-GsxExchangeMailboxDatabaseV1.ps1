<#
		.SYNOPSIS
		This command retrieves the Exchage server mailbox database copy status.

		.DESCRIPTION
		This command retrieves the Exchage server mailbox database copy status.

        .PARAMETER ExchangeServer
        Type: [String]
		Description: Defines the Exchange Server hostname.

		.PARAMETER PowerShellLocal
        Type: [Bool]
        Default value: $false
        Description: Defines whether we use PowerShell locally or in a PSSession.

		.EXAMPLE
		Running the Get-GsxExchangeMailboxDatabaseV1 command

            PS> Get-GsxExchangeMailboxDatabaseV1 -ExchangeServer 'ex16-a.gsxclients.com'

        .OUTPUTS
		Here is an example of the output:

		PropertyId 	Index       	Value       CommandCode CommandMessage
		---------- 	-----       	-----       ----------- --------------
        1 			MB03\EX16-A 	MB03\EX16-A 		  0
        2 			MB03\EX16-A 	Mounted     		  0
        3 			MB03\EX16-A 	1           		  0
        4 			MB03\EX16-A 	            		  0
        5 			MB03\EX16-A 	Healthy     		  0
        6 			MB03\EX16-A 	0           		  0
        7 			MB03\EX16-A 	0           		  0
        8 			MB03\EX16-A 	            		  0
		9 			MB03\EX16-A 	00:00:00              0
		10 			MB03\EX16-A 	1.00:00:00            0
		11 			MB03\EX16-A 	00:18:54.0837992      0
		12 			MB03\EX16-A 	0                     0
		13 			MB03\EX16-A 	False                 0
		14 			MB03\EX16-A 	None                  0
		15 			MB03\EX16-A 	None                  0
		16 			MB03\EX16-A 		                  0
		17 			MB03\EX16-A 		                  0
		18 			MB03\EX16-A 	33            		  0
		19 			MB03\EX16-A 	95.19 GB              0
		20 			MB03\EX16-A 	95.19 GB              0
		21 			MB03\EX16-A 	23.65 MB              0
		22 			MB03\EX16-A 	23.65 MB              0
        1 			MB04\EX16-A 	MB04\EX16-A 		  0
        2 			MB04\EX16-A 	Mounted     		  0
        3 			MB04\EX16-A 	2           		  0
        4 			MB04\EX16-A 	            		  0
        5 			MB04\EX16-A 	Healthy     		  0
        6 			MB04\EX16-A 	0           		  0
        7 			MB04\EX16-A 	0           		  0
        8 			MB04\EX16-A 	            		  0
		9 			MB04\EX16-A 	00:00:00              0
		10 			MB04\EX16-A 	1.00:00:00            0
		11 			MB04\EX16-A 	00:18:54.0837992      0
		12 			MB04\EX16-A 	0                     0
		13 			MB04\EX16-A 	False                 0
		14 			MB04\EX16-A 	None                  0
		15 			MB04\EX16-A 	None                  0
		16 			MB04\EX16-A 		                  0
		17 			MB04\EX16-A 		                  0
		18 			MB04\EX16-A 	33            		  0
		19 			MB04\EX16-A 	95.19 GB              0
		20 			MB04\EX16-A 	95.19 GB              0
		21 			MB04\EX16-A 	23.65 MB              0
		22 			MB04\EX16-A 	23.65 MB              0

		The output from this command will be an object that has the following properties available:

			| Properties     | Type                       |
			| -------------- | -------------------------- |
			| PropertyId     | Int                        |
			| Index          | String                     |
			| Value          | Depends on the Property Id |
			| CommandCode    | Int                        |
			| CommandMessage | String                     |

		.NOTES
        Property Ids:

			| PropertyId | Value            			| Type     	| Description            															|
			| ---------- | ------------------			| -------- 	| -------------------------------------------------------------- 					|
			| 1          | Name         				| String   	| Exchange server mailbox database unique name.    									|
			| 2          | Status     					| String   	| Exchange server mailbox database status.     			 							|
			| 3          | ActivationPreference 		| Uint32   	| Exchange server mailbox database activation preference. 							|
			| 4          | LastInspectedLogTime			| DateTime 	| Exchange server mailbox database last inspected log time. 						|
			| 5          | ContentIndexState    		| String 	| Exchange server mailbox database content index state.    							|
			| 6          | CopyQueueLength     			| Uint32   	| Exchange server mailbox database copy queue length.  	 							|
			| 7          | ReplayQueueLength   			| Uint32   	| Exchange server mailbox database replay queue length.	 							|
			| 8          | LastFullBackup   			| DateTime  | Exchange server mailbox database last full backup.   	 							|
			| 9          | ConfiguredLagTime    		| String 	| Exchange server mailbox database replay lag status configured lag time.   		|
			| 10         | ReplayLagMaxDelay    		| String	| Exchange server mailbox database replay lag status replay lag max delay.  		|
			| 11         | ActualLagTime     			| String	| Exchange server mailbox database replay lag status actual lag time.   			|
			| 12         | Percentage          			| Double	| Exchange server mailbox database replay lag status percentage.   	 				|
			| 13         | Enabled       	   			| Boolean	| Exchange server mailbox database replay lag status enabled.   	 				|
			| 14         | PlayDownReason       		| String	| Exchange server mailbox database replay lag status play down reason.   			|
			| 15         | ReplaySuspendReason  		| String	| Exchange server mailbox database replay lag status replay suspend reason. 		|
			| 16         | ReplaySuspendReasonMessage  	| String	| Exchange server mailbox database replay lag status replay suspend reason message. |
			| 17         | DisabledReason  				| String	| Exchange server mailbox database replay lag status disabled reason. 		|
			| 18         | Percentage		   			| Double	| Exchange server mailbox database database seed status percentage.   	 			|
			| 19         | Read         	 			| String	| Exchange server mailbox database database seed status read.   	 				|
			| 20         | Written        				| String	| Exchange server mailbox database database seed status written.   	 				|
			| 21         | ReadPerSec     				| String	| Exchange server mailbox database database seed status read per sec.   			|
			| 22         | WrittenPerSec   				| String	| Exchange server mailbox database database seed status written per sec.   			|
#>

param (
	[string] $ExchangeServer,
	[bool] $PowerShellLocal = $false
)

Function New-GsxDefaultOutput($OutputObject, $CommandCode, $CommandMessage){
	$OutputObject.AddResult(1,  $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(2,  $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(3,  $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(4,  $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(5,  $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(6,  $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(7,  $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(8,  $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(9,  $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(10, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(11, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(12, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(13, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(14, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(15, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(16, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(17, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(18, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(19, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(20, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(21, $null, $null, $CommandCode, $CommandMessage)
	$OutputObject.AddResult(22, $null, $null, $CommandCode, $CommandMessage)
}

# Storing current error action preference
$OldErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = 'Stop'

$Output = New-Object Gsx.Robot.PSModel.PSOutput

$CommandParameters = @{
	ScriptBlock  = $null
	ArgumentList = $null
}

if (!$PowerShellLocal) {
	$CommandParameters.Session = Get-PSSession
}

$CommandMessage = $null
$CommandCode = 0

# Getting mailbox databases
try{
	$CommandString = "Get-MailboxDatabaseCopyStatus -Server $ExchangeServer | Select-Object Name, Status, ActivationPreference, LastInspectedLogTime, ContentIndexState, CopyQueueLength, ReplayQueueLength, LastFullBackup, DatabaseSeedStatus, ReplayLagStatus"
	$CommandAsScriptBlock = [Scriptblock]::Create($CommandString)
	$CommandParameters.ScriptBlock = $CommandAsScriptBlock

	Write-Verbose 'Retrieving mailbox database(s)...'
	$MailboxDatabases = Invoke-Command @CommandParameters

	if( ($null -ne $MailboxDatabases) -and ($MailboxDatabases.Count -ne 0) ) {
		foreach ($MailboxDatabase in $MailboxDatabases) {
			$Output.AddResult(1,  $MailboxDatabase.Name, $MailboxDatabase.Name,         							$CommandCode, $CommandMessage)
			$Output.AddResult(2,  $MailboxDatabase.Name, $MailboxDatabase.Status.ToString(),    					$CommandCode, $CommandMessage)
			$Output.AddResult(3,  $MailboxDatabase.Name, $MailboxDatabase.ActivationPreference,						$CommandCode, $CommandMessage)
			$Output.AddResult(4,  $MailboxDatabase.Name, $MailboxDatabase.LastInspectedLogTime, 					$CommandCode, $CommandMessage)
			$Output.AddResult(5,  $MailboxDatabase.Name, $MailboxDatabase.ContentIndexState.ToString(), 			$CommandCode, $CommandMessage)
			$Output.AddResult(6,  $MailboxDatabase.Name, $MailboxDatabase.CopyQueueLength,      					$CommandCode, $CommandMessage)
			$Output.AddResult(7,  $MailboxDatabase.Name, $MailboxDatabase.ReplayQueueLength,    					$CommandCode, $CommandMessage)
			$Output.AddResult(8,  $MailboxDatabase.Name, $MailboxDatabase.LastFullBackup,       					$CommandCode, $CommandMessage)

			$Output.AddResult(9,  $MailboxDatabase.Name, $MailboxDatabase.ReplayLagStatus.ConfiguredLagTime,    	$CommandCode, $CommandMessage)
			$Output.AddResult(10, $MailboxDatabase.Name, $MailboxDatabase.ReplayLagStatus.ReplayLagMaxDelay,   		$CommandCode, $CommandMessage)
			$Output.AddResult(11, $MailboxDatabase.Name, $MailboxDatabase.ReplayLagStatus.ActualLagTime,       		$CommandCode, $CommandMessage)
			$Output.AddResult(12, $MailboxDatabase.Name, $MailboxDatabase.ReplayLagStatus.Percentage,       		$CommandCode, $CommandMessage)
			$Output.AddResult(13, $MailboxDatabase.Name, $MailboxDatabase.ReplayLagStatus.Enabled,       			$CommandCode, $CommandMessage)
			$Output.AddResult(14, $MailboxDatabase.Name, $MailboxDatabase.ReplayLagStatus.PlayDownReason,     		$CommandCode, $CommandMessage)
			$Output.AddResult(15, $MailboxDatabase.Name, $MailboxDatabase.ReplayLagStatus.ReplaySuspendReason, 		$CommandCode, $CommandMessage)
			$Output.AddResult(16, $MailboxDatabase.Name, $MailboxDatabase.ReplayLagStatus.ReplaySuspendReasonMessage, 		$CommandCode, $CommandMessage)
			$Output.AddResult(17, $MailboxDatabase.Name, $MailboxDatabase.ReplayLagStatus.DisabledReason, 			$CommandCode, $CommandMessage)

			$Output.AddResult(18, $MailboxDatabase.Name, $MailboxDatabase.DatabaseSeedStatus.ProgressPercentage,	$CommandCode, $CommandMessage)
			$Output.AddResult(19, $MailboxDatabase.Name, $MailboxDatabase.DatabaseSeedStatus.BytesRead,       		$CommandCode, $CommandMessage)
			$Output.AddResult(20, $MailboxDatabase.Name, $MailboxDatabase.DatabaseSeedStatus.BytesWritten,       	$CommandCode, $CommandMessage)
			$Output.AddResult(21, $MailboxDatabase.Name, $MailboxDatabase.DatabaseSeedStatus.BytesReadPerSec,       $CommandCode, $CommandMessage)
			$Output.AddResult(22, $MailboxDatabase.Name, $MailboxDatabase.DatabaseSeedStatus.BytesWrittenPerSec,    $CommandCode, $CommandMessage)
		}
	}
	else{
		New-GsxDefaultOutput -OutputObject $Output -CommandCode $CommandCode -CommandMessage $CommandMessage
	}
}
catch{
	$CommandMessage = $_.Exception.Message
	$CommandCode = 1

	New-GsxDefaultOutput -OutputObject $Output -CommandCode $CommandCode -CommandMessage $CommandMessage
}

$ErrorActionPreference = $OldErrorActionPreference

# We will exit the PowerShell by returning this exact object
Return($Output)