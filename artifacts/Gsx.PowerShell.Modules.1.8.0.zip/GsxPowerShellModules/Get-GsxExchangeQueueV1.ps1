<#
		.SYNOPSIS
		This command retrieves queue(s) information based on the “Get-Queue” cmdlets part of the Exchange Management Shell.

		.DESCRIPTION
		This command retrieves queue(s) information based on the “Get-Queue” cmdlets part of the Exchange Management Shell.

        .PARAMETER PowerShellLocal
        Type: [Bool]
        Default value: $false
        Description: Defines whether we use PowerShell locally or in a PSSession.

		.EXAMPLE
		Running the Get-GsxExchangeQueueV1 command

            PS> Get-GsxExchangeQueueV1

        .OUTPUTS
		Here is an example of the output:

		PropertyId Index             Value             CommandCode CommandMessage
		---------- -----             -----             ----------- --------------
         1 		   EX16-A\Submission EX16-A\Submission           0
         2 		   EX16-A\Submission Undefined                   0
         3 		   EX16-A\Submission Ready                       0
         4 		   EX16-A\Submission 0                           0
         5 		   EX16-A\Submission 0                           0
         6 		   EX16-A\Submission Normal                      0
         7 		   EX16-A\Submission 0                           0
         8 		   EX16-A\Submission Submission                  0
         9 		   EX16-A\Submission 0                           0
        10 		   EX16-A\Submission 0                           0

		The output from this command will be an object that has the following properties available:

			| Properties     | Type                       |
			| -------------- | -------------------------- |
			| PropertyId     | Int                        |
			| Index          | String                     |
			| Value          | Depends on the Property Id |
			| CommandCode    | Int                        |
			| CommandMessage | String                     |

		.NOTES
        Property Ids:

			| PropertyId | Value            | Type   | Description            |
			| ---------- | ---------------  | ------ | --------------------------------------- 	|
			| 1          | Identity         | String | Exchange queue unique identity.         	|
			| 2          | DeliveryType     | String | Exchange queue delivery type.     		|
			| 3          | Status           | String | Exchange queue status.           		|
			| 4          | MessageCount     | Uint32 | Messages count in Exchange queue.      	|
			| 5          | Velocity         | Uint32 | Velocity of Exchange queue.          	|
			| 6          | RiskLevel     	| String | Exchange queue risk level.        		|
			| 7          | OutboundIPPool   | Uint32 | Exchange queue outbound IP pool.   		|
			| 8          | NextHopDomain    | String | Exchange queue NextHopDomain    			|
			| 9          | IncomingRate     | Uint32 | Exchange queue incoming rate     		|
			| 10         | OutgoingRate     | Uint32 | Exchange queue outgoing rate     		|

#>

param (
	[bool] $PowerShellLocal = $false
)

Function New-GsxDefaultOutput($OutputObject, $CommandCode, $CommandMessage){
	$Output.AddResult(1,  $null, $null,	$CommandCode, $CommandMessage)
	$Output.AddResult(2,  $null, $null, $CommandCode, $CommandMessage)
	$Output.AddResult(3,  $null, $null, $CommandCode, $CommandMessage)
	$Output.AddResult(4,  $null, $null, $CommandCode, $CommandMessage)
	$Output.AddResult(5,  $null, $null, $CommandCode, $CommandMessage)
	$Output.AddResult(6,  $null, $null, $CommandCode, $CommandMessage)
	$Output.AddResult(7,  $null, $null, $CommandCode, $CommandMessage)
	$Output.AddResult(8,  $null, $null, $CommandCode, $CommandMessage)
	$Output.AddResult(9,  $null, $null, $CommandCode, $CommandMessage)
	$Output.AddResult(10, $null, $null, $CommandCode, $CommandMessage)
}

# Storing current error action preference
$OldErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = 'Stop'

$Output = New-Object Gsx.Robot.PSModel.PSOutput

$CommandParameters = @{
	ScriptBlock  = $null
}

if (!$PowerShellLocal) {
	$CommandParameters.Session = Get-PSSession
}

# Getting queues
$CommandMessage = $null
$CommandCode = 0

try{
	$CommandParameters.ScriptBlock = {
		Get-Queue | Select-Object Identity, DeliveryType, Status, MessageCount, Velocity, RiskLevel, OutboundIPPool, NextHopDomain, IncomingRate, OutgoingRate
	}

	Write-Verbose 'Retrieving queue(s)...'
	$Queues = Invoke-Command @CommandParameters

	if( ($null -ne $Queues) -and ($Queues.Count -ne 0) ) {
		foreach ($Queue in $Queues) {
			if ($Queue.DeliveryType.ToString() -ne "ShadowRedundancy" ) {
				$Output.AddResult(1,  $Queue.Identity.ToString(), $Queue.Identity.ToString(),      $CommandCode, $CommandMessage)
				$Output.AddResult(2,  $Queue.Identity.ToString(), $Queue.DeliveryType.ToString(),  $CommandCode, $CommandMessage)
				$Output.AddResult(3,  $Queue.Identity.ToString(), $Queue.Status.ToString(),        $CommandCode, $CommandMessage)
				$Output.AddResult(4,  $Queue.Identity.ToString(), $Queue.MessageCount,     		   $CommandCode, $CommandMessage)
				$Output.AddResult(5,  $Queue.Identity.ToString(), $Queue.Velocity,  	    	   $CommandCode, $CommandMessage)
				$Output.AddResult(6,  $Queue.Identity.ToString(), $Queue.RiskLevel.ToString(),     $CommandCode, $CommandMessage)
				$Output.AddResult(7,  $Queue.Identity.ToString(), $Queue.OutboundIPPool,   		   $CommandCode, $CommandMessage)
				$Output.AddResult(8,  $Queue.Identity.ToString(), $Queue.NextHopDomain,    		   $CommandCode, $CommandMessage)
				$Output.AddResult(9,  $Queue.Identity.ToString(), $Queue.IncomingRate,     		   $CommandCode, $CommandMessage)
				$Output.AddResult(10, $Queue.Identity.ToString(), $Queue.OutgoingRate,     		   $CommandCode, $CommandMessage)
			}
		}
	}
	else{
		New-GsxDefaultOutput -OutputObject $Output -CommandCode $CommandCode -CommandMessage $CommandMessage
	}
}
catch{
	$CommandMessage = $_.Exception.Message
	$CommandCode = 1

	New-GsxDefaultOutput -OutputObject $Output -CommandCode $CommandCode -CommandMessage $CommandMessage
}

$ErrorActionPreference = $OldErrorActionPreference

# We will exit the PowerShell by returning this exact object
Return($Output)