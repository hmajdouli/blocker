<#
		.SYNOPSIS
		This command retrieves the health of Database Availability Groups (DAGs) of an Exchange on-premises organization.

		.DESCRIPTION
		This command retrieves the health of Database Availability Groups (DAGs) of an Exchange on-premises organization.

		.PARAMETER DAGName
        Type: [String]
		Description: Defines the Exchange DAG Address.

		.PARAMETER ChecksWhereToIgnoreDatabases
        Type: [String[]]
        Default value: @()
		Description: Defines the Health Ckecks where to ignore erroneous Mailbox Databases.

		.PARAMETER MailboxDatabasesToIgnore
        Type: [String[]]
        Default value: @()
		Description: Defines the Mailbox Databases to ignore when calculating the replication health check status.

		.PARAMETER DatabaseMatchesRegExp
		Type: [String
        Default value: "database '(([^'\\]+)(?:\\[^'\\]+)?)'"
		Description: Defines the regular expression to match the database names inside the health check error message.

		.PARAMETER TransientEventSuppressionWindow
		Type: [UInt32]
		Default value: 0
		Description: The TransientEventSuppressionWindow parameter specifies the number of minutes that the queue
		lengths can be exceeded before the queue length tests are considered to have failed.
		This parameter is used to reduce the number of failures due to transient load generation.

        .PARAMETER PowerShellLocal
        Type: [Bool]
        Default value: $false
        Description: Defines whether we use PowerShell locally or in a PSSession.

		.EXAMPLE
		Running the Get-GsxExchangeReplicationHealthV1 command

            PS> Get-GsxExchangeReplicationHealthV1 -DAGName 'EX16DAG'

        .OUTPUTS
		Here is an example of the output: TODO

		PropertyId Index             			Value             	CommandCode 	CommandMessage
		---------- -----             			-----             	----------- 	--------------
		 1 		   EX16-B\DagMembersUp         	EX16-B				0
		 2 		   EX16-B\DagMembersUp         	DagMembersUp		0
		 3 		   EX16-B\DagMembersUp         	Passed				0
		 4 		   EX16-B\DagMembersUp								0
		 1 		   EX16-B\MonitoringService    	EX16-B				0
		 2 		   EX16-B\MonitoringService    	MonitoringService	0
		 3 		   EX16-B\MonitoringService    	Passed				0
		 4 		   EX16-B\MonitoringService							0
		 1 		   EX16-B\ClusterNetwork       	EX16-B				0
		 2 		   EX16-B\ClusterNetwork       	ClusterNetwork		0
		 3 		   EX16-B\ClusterNetwork       	Passed				0
		 4 		   EX16-B\ClusterNetwork							0
		 1 		   EX16-B\QuorumGroup          	EX16-B				0
		 2 		   EX16-B\QuorumGroup          	QuorumGroup			0
		 3 		   EX16-B\QuorumGroup          	Failed				0
		 4 		   EX16-B\QuorumGroup          	Failures:...		0
		 1 		   EX16-B\FileShareQuorum      	EX16-B				0
		 2 		   EX16-B\FileShareQuorum      	FileShareQuorum		0
		 3 		   EX16-B\FileShareQuorum      	Failed				0
		 4 		   EX16-B\FileShareQuorum      	Failures:...		0

		The output from this command will be an object that has the following properties available:

			| Properties     | Type                       |
			| -------------- | -------------------------- |
			| PropertyId     | Int                        |
			| Index          | String                     |
			| Value          | Depends on the Property Id |
			| CommandCode    | Int                        |
			| CommandMessage | String                     |

		.NOTES
        Property Ids:

			| PropertyId | Value         | Type   | Description            						|
			| ---------- | ------------- | ------ | --------------------------------------- 	|
			| 1          | Server        | String | Exchange DAG server name.         			|
			| 2          | Check         | String | Exchange DAG health check name.         	|
			| 3          | Status	     | String | Exchange DAG health check status.     		|
			| 4          | Error         | String | Exchange DAG health check errors (if any).	|

#>

param (
	[string] $DAGName,
	[string[]] $ChecksWhereToIgnoreDatabases,
	[string[]] $MailboxDatabasesToIgnore,
	[string] $DatabaseMatchesRegExp,
	[uint32] $TransientEventSuppressionWindow = 0,
	[bool] $PowerShellLocal = $false
)

if ([string]::IsNullOrEmpty($DatabaseMatchesRegExp)) {
	$DatabaseMatchesRegExp = "database '(([^'\\]+)(?:\\[^'\\]+)?)'"
}

Function New-GsxDefaultOutput($OutputObject, $CommandCode, $CommandMessage){
	$Output.AddResult(1,  $null, $null,	$CommandCode, $CommandMessage)
	$Output.AddResult(2,  $null, $null, $CommandCode, $CommandMessage)
	$Output.AddResult(3,  $null, $null, $CommandCode, $CommandMessage)
	$Output.AddResult(4,  $null, $null, $CommandCode, $CommandMessage)
}

# Storing current error action preference
$OldErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = 'Stop'

$Output = New-Object Gsx.Robot.PSModel.PSOutput

$CommandParameters = @{
	ScriptBlock  = $null
	ArgumentList = $null
}

if (!$PowerShellLocal) {
	$CommandParameters.Session = Get-PSSession
}

$CommandMessage = $null
$CommandCode = 0

# Getting replication health
try{
	$CommandString = "Test-ReplicationHealth -DatabaseAvailabilityGroup '$DAGName' -TransientEventSuppressionWindow '$TransientEventSuppressionWindow' | Select-Object Server, Check, Result, Error"
	$CommandAsScriptBlock = [Scriptblock]::Create($CommandString)
	$CommandParameters.ScriptBlock = $CommandAsScriptBlock

	Write-Verbose 'Retrieving health check(s)...'
	$HealthChecks = Invoke-Command @CommandParameters

	if($null -ne $HealthChecks) {
		foreach ($HealthCheck in $HealthChecks) {
			$CheckStatus = $HealthCheck.Result.ToString()
			if ($CheckStatus -eq "*FAILED*" -or $CheckStatus -eq "*FAILURE*" -or $CheckStatus -eq "Failure") {
				$CheckStatus = "Failed"
			}
			if (($ChecksWhereToIgnoreDatabases -contains $HealthCheck.Check) -and ($null -ne $MailboxDatabasesToIgnore) -and ($CheckStatus -eq "Failed" -or $CheckStatus -eq "Warning") -and ($null -ne $HealthCheck.Error)) {
				$AllErrorDatabasesAreIgnored = $true
				$Matches = ([regex]$DatabaseMatchesRegExp).Matches($HealthCheck.Error);
				if ($Matches.Count -gt 0) {
					foreach ($Match in $Matches){
						if ((-Not ($MailboxDatabasesToIgnore -contains $Match.Groups[1].Value)) -and
						    (-Not ($MailboxDatabasesToIgnore -contains $Match.Groups[2].Value))) {
							$AllErrorDatabasesAreIgnored = $false
						}
					}
					if ($AllErrorDatabasesAreIgnored -eq $true) {
						$CheckStatus = "$($CheckStatus) Ignored"
					}
				}
			}
			$Output.AddResult(1, "$($HealthCheck.Server)\$($HealthCheck.Check)", $HealthCheck.Server,   $CommandCode, $CommandMessage)
			$Output.AddResult(2, "$($HealthCheck.Server)\$($HealthCheck.Check)", $HealthCheck.Check,    $CommandCode, $CommandMessage)
			$Output.AddResult(3, "$($HealthCheck.Server)\$($HealthCheck.Check)", $CheckStatus,  		$CommandCode, $CommandMessage)
			$Output.AddResult(4, "$($HealthCheck.Server)\$($HealthCheck.Check)", $HealthCheck.Error,    $CommandCode, $CommandMessage)
		}
	}
	else{
		New-GsxDefaultOutput -OutputObject $Output -CommandCode $CommandCode -CommandMessage $CommandMessage
	}
}
catch{
	$CommandMessage = $_.Exception.Message
	$CommandCode = 1

	New-GsxDefaultOutput -OutputObject $Output -CommandCode $CommandCode -CommandMessage $CommandMessage
}

$ErrorActionPreference = $OldErrorActionPreference

# We will exit the PowerShell by returning this exact object
Return($Output)