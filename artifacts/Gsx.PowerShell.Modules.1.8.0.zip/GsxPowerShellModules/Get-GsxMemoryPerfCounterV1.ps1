param (
	[bool] $PowerShellLocal = $false
)

$Output = New-Object Gsx.Robot.PSModel.PSOutput

# Import Module
Import-Module "$pwd\GsxPowerShellModules\Modules\GsxModules.psm1" -Force

$ParametersHashtable = @{}
$UsedParameters = $PSBoundParameters.GetEnumerator()

$UsedParameters.ForEach({$ParametersHashtable.Add($_.Key, $_.Value)})

# Getting memory perf counters
$MemoryCountersOutput = Get-GsxMemoryPerfCounterV1 @ParametersHashtable
$MemoryCounters = @(($MemoryCountersOutput.MemoryCounters | ConvertFrom-Json))
$CommandCode = $MemoryCountersOutput.CommandCode
$CommandMessage = $MemoryCountersOutput.CommandMessage

# This object with Property ID set to -1 is the status of the command
$Output.AddResult(-1, $null, $null, $CommandCode, $CommandMessage)

if([bool]$MemoryCounters) {
	foreach ($MemoryCounter in $MemoryCounters) {
		$Output.AddResult(1, $MemoryCounter.Name, $MemoryCounter.MemoryTotalInMegaBytes, $CommandCode, $CommandMessage)
		$Output.AddResult(2, $MemoryCounter.Name, $MemoryCounter.MemoryUsedInMegaBytes,  $CommandCode, $CommandMessage)
		$Output.AddResult(3, $MemoryCounter.Name, $MemoryCounter.MemoryUsedInPercentage, $CommandCode, $CommandMessage)
	}
}

# We will exit the PowerShell by returning this exact object
Return($Output)