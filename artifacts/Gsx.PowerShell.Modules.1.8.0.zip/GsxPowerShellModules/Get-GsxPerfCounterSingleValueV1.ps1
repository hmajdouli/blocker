param (
	$Counter,
	[int]  $SampleInterval = 1,
	[bool] $PowerShellLocal = $false
)

$Output = New-Object Gsx.Robot.PSModel.PSOutput

# Import Module
Import-Module "$pwd\GsxPowerShellModules\Modules\GsxModules.psm1" -Force

$ParametersHashtable = @{}
$UsedParameters = $PSBoundParameters.GetEnumerator()

$UsedParameters.ForEach({$ParametersHashtable.Add($_.Key, $_.Value)})

# Getting PerfCounters
$PerfCountersOutput = Get-GsxPerfCounterSingleValueV1 @ParametersHashtable
$PerfCounter = $PerfCountersOutput.PerfCounter
$CommandCode = $PerfCountersOutput.CommandCode
$CommandMessage = $PerfCountersOutput.CommandMessage

# This object with Property ID set to -1 is the status of the command
$Output.AddResult(-1, $null, $null, $CommandCode, $CommandMessage)

$Output.AddResult(1, $null, $PerfCounter, $CommandCode, $CommandMessage)

# We will exit the PowerShell by returning this exact object
Return($Output)