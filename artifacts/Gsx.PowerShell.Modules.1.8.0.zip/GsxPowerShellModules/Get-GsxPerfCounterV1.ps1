param (
	$Counter,
	[int]  $SampleInterval = 1,
	[bool] $PowerShellLocal = $false
)

$Output = New-Object Gsx.Robot.PSModel.PSOutput

# Import Module
Import-Module "$pwd\GsxPowerShellModules\Modules\GsxModules.psm1" -Force

$ParametersHashtable = @{}
$UsedParameters = $PSBoundParameters.GetEnumerator()

$UsedParameters.ForEach({$ParametersHashtable.Add($_.Key, $_.Value)})

# Getting PerfCounters
$PerfCountersOutput = Get-GsxPerfCounterV1 @ParametersHashtable
$PerfCounters = @(($PerfCountersOutput.PerfCounters | ConvertFrom-Json))
$CommandCode = $PerfCountersOutput.CommandCode
$CommandMessage = $PerfCountersOutput.CommandMessage

# This object with Property ID set to -1 is the status of the command
$Output.AddResult(-1, $null, $null, $CommandCode, $CommandMessage)

if([bool]$PerfCounters) {
	foreach ($PerfCounter in $PerfCounters) {
		foreach ($Stat in $PerfCounter.psobject.properties) {
			$Output.AddResult(1, $Stat.Name, $Stat.Value, $CommandCode, $CommandMessage)
		}
	}
}

# We will exit the PowerShell by returning this exact object
Return($Output)