<#
		.SYNOPSIS
		This command will return the services from a computer.

		.DESCRIPTION
		This command will return the services from a computer.

		.LINK
		More information about the Win32_Service class
		https://docs.microsoft.com/en-us/windows/desktop/cimwin32prov/win32-service

        .PARAMETER ServiceName
        Type: [String[]]
        Description: Specifies, as a string array, the display names of services to be retrieved. Wildcards are permitted. By default, this cmdlet gets all services on the computer.

        .PARAMETER PowerShellLocal
        Type: [Bool]
        Default value: $false
        Description: Defines whether we use PowerShell locally or in a PSSession.

		.EXAMPLE
		Running the Get-GsxServiceV1 command

            PS> Get-GsxServiceV1

        .OUTPUTS
		Here is an example of the output:

			PropertyId Index                                          Value CommandCode CommandMessage
			---------- -----                                          ----- ----------- --------------
					1 GSX Service Running                             1988           0
					2 GSX Service Running              Gsx_service_running           0
					3 GSX Service Running              GSX Service Running           0
					4 GSX Service Running                             Auto           0
					5 GSX Service Running                          Running           0
					6 GSX Service Running      NT AUTHORITY\NetworkService           0
					1 GSX Service Stopped                             3152           0
					2 GSX Service Stopped              Gsx_service_stopped           0
					3 GSX Service Stopped              GSX Service Stopped           0
					4 GSX Service Stopped                             Auto           0
					5 GSX Service Stopped                          Stopped           0
					6 GSX Service Stopped                      LocalSystem           0
					1 GSX Service Not Found                                          1
					2 GSX Service Not Found                                          1
					3 GSX Service Not Found          GSX Service Not Found           1
					4 GSX Service Not Found                                          1
					5 GSX Service Not Found                                          1 Service not found
					6 GSX Service Not Found                                          1


		The output from this command will be an object that has the following properties available:

			| Properties     | Type                       |
			| -------------- | -------------------------- |
			| PropertyId     | Int                        |
			| Index          | String                     |
			| Value          | Depends on the Property Id |
			| CommandCode    | Int                        |
			| CommandMessage | String                     |

		.NOTES
        Property Ids:

			| PropertyId | Value       | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
			| ---------- | ----------- | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
			| 1          | ProcessId   | Uint32 | Process identifier of the service.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
			| 2          | ServiceName | String | Unique identifier of the service that provides an indication of the functionality that is managed.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
			| 3          | DisplayName | String | Short description of the service —a one-line string.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
			| 4          | StartupType | String | Start mode of the Windows base service.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
			| 5          | Status      | String | Current state of the base service.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
			| 6          | LogonAs     | String | Account name under which a service runs. Depending on the service type, the account name may be in the form of "DomainName\Username" or UPN format ("*Username@DomainName*"). The service process is logged by using one of these two forms when it runs. If the account belongs to the built-in domain, then ".\Username" can be specified. For kernel or system-level drivers, StartName contains the driver object name (that is, "\FileSystem\Rdr" or "\Driver\Xns") which the I/O system uses to load the device driver. Additionally, if NULL is specified, the driver runs with a default object name created by the I/O system based on the service name. |


#>

param(
	[string[]] $ServiceName,
	[bool] $PowerShellLocal = $false
)

# Storing current error action preference
$OldErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = 'Stop'

$Output = New-Object Gsx.Robot.PSModel.PSOutput

$CommandParameters = @{
	ScriptBlock  = $null
	ArgumentList = $null
}

if (!$PowerShellLocal) {
	$CommandParameters.Session = Get-PSSession
}

$CimInstanceParameters = @{
	ClassName = 'Win32_Service'
}

foreach ($Service in $ServiceName) {

	$CommandMessage = $null
	$CommandCode = 0

	$CimInstanceParameters.Filter = "Name = '$Service'"

	$CommandParameters.ArgumentList = $CimInstanceParameters
	$CommandParameters.ScriptBlock = { param ($ArgumentList) (Get-CimInstance @ArgumentList) }

	Write-Verbose 'Retrieving service...'
	$ServiceReturned = Invoke-Command @CommandParameters

	if ([string]::IsNullOrEmpty($ServiceReturned)) {

		$CommandCode = 1

		$Output.AddResult(1, $Service, $null,     $CommandCode, $null)     # ProcessId
		$Output.AddResult(2, $Service, $null,     $CommandCode, $null)     # ServiceName
		$Output.AddResult(3, $Service, $Service,  $CommandCode, $null)     # Name
		$Output.AddResult(4, $Service, $null,     $CommandCode, $null)     # StartupType
		$Output.AddResult(5, $Service, 'Missing', $CommandCode, 'Missing') # Status
		$Output.AddResult(6, $Service, $null,     $CommandCode, $null)     # LogonAs

		continue

	}

	$Properties = @(
		@{ Label = "ProcessId";   Expression = { [uint32]$_.ProcessId } },
		@{ Label = "ServiceName"; Expression = { [string]$_.Name } },
		@{ Label = "DisplayName"; Expression = { [string]$_.Caption } },
		@{ Label = "StartupType"; Expression = { [string]$_.StartMode } },
		@{ Label = "Status";      Expression = { [string]$_.State } },
		@{ Label = "LogonAs";     Expression = { [string]$_.StartName } }
	)

	$ServiceWithCustomProperties = $ServiceReturned | Select-Object $Properties -Unique

	$Output.AddResult(1, $Service, $ServiceWithCustomProperties.ProcessId,   $CommandCode, $CommandMessage)
	$Output.AddResult(2, $Service, $ServiceWithCustomProperties.ServiceName, $CommandCode, $CommandMessage)
	$Output.AddResult(3, $Service, $ServiceWithCustomProperties.DisplayName, $CommandCode, $CommandMessage)
	$Output.AddResult(4, $Service, $ServiceWithCustomProperties.StartupType, $CommandCode, $CommandMessage)
	$Output.AddResult(5, $Service, $ServiceWithCustomProperties.Status,      $CommandCode, $CommandMessage)
	$Output.AddResult(6, $Service, $ServiceWithCustomProperties.LogonAs,     $CommandCode, $CommandMessage)

}

$ErrorActionPreference = $OldErrorActionPreference

# We will exit the PowerShell by returning this exact object
Return($Output)