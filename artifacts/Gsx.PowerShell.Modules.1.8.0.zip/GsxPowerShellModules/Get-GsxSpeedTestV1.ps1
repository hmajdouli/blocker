﻿param (
	$Hostname,
	$PortRange = 9,
	$Iteration = 10,
	$ParallelStreams = 10
)

$Output = New-Object Gsx.Robot.PSModel.PSOutput

# Import Module
Import-Module "$pwd\GsxPowerShellModules\Modules\GsxModules.psm1" -Force

$ParametersHashtable = @{}
$UsedParameters = $PSBoundParameters.GetEnumerator()

$UsedParameters.ForEach({$ParametersHashtable.Add($_.Key, $_.Value)})

# Getting Network Bandwidth
$SpeedTestOutput = Get-GsxSpeedTestV1 @ParametersHashtable
$SpeedTestMetrics = @(($SpeedTestOutput.SpeedTestMetrics | ConvertFrom-Json))
$CommandCode = $SpeedTestOutput.CommandCode
$CommandMessage = $SpeedTestOutput.CommandMessage

# This object with Property ID set to -1 is the status of the command
$Output.AddResult(-1, $null, $null, $CommandCode, $CommandMessage)

if([bool]$SpeedTestMetrics) {
	foreach ($Metric in $SpeedTestMetrics) {
		$Output.AddResult(1,  $null, $Metric.Hostname,                        $CommandCode, $CommandMessage) # String
		$Output.AddResult(2,  $null, $Metric.UDPJitterInMs,                   $CommandCode, $CommandMessage) # Int
		$Output.AddResult(3,  $null, $Metric.UDPSeconds,                      $CommandCode, $CommandMessage) # Int
		$Output.AddResult(4,  $null, $Metric.UDPMbitsPerSecond,               $CommandCode, $CommandMessage) # Int
		$Output.AddResult(5,  $null, $Metric.UDPLostPercent,                  $CommandCode, $CommandMessage) # Int
		$Output.AddResult(6,  $null, $Metric.UDPOutOfOrder,                   $CommandCode, $CommandMessage) # Int
		$Output.AddResult(7,  $null, $Metric.UDPLostPackets,                  $CommandCode, $CommandMessage) # Int
		$Output.AddResult(8,  $null, $Metric.UDPPackets,                      $CommandCode, $CommandMessage) # Int
		$Output.AddResult(9,  $null, $Metric.UDPPacketOutOfOrder,             $CommandCode, $CommandMessage) # Int
		$Output.AddResult(10, $null, $Metric.TCPUploadSentInMbitsPerSecond,   $CommandCode, $CommandMessage) # Int
		$Output.AddResult(11, $null, $Metric.TCPDownloadSentInMbitsPerSecond, $CommandCode, $CommandMessage) # Int
	}
}

# We will exit the PowerShell by returning this exact object
Return($Output)