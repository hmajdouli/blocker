param (
	$LogName,
	$ProviderName,
	$Path,
	$Keywords,
	$ID,
	$Level,
	$UserID,
	$Data,
	$MaxEvents,
	[bool] $PowerShellLocal = $false
)

$Output = New-Object Gsx.Robot.PSModel.PSOutput

# Import Module
Import-Module "$pwd\GsxPowerShellModules\Modules\GsxModules.psm1" -Force

$ParametersHashtable = @{}
$UsedParameters = $PSBoundParameters.GetEnumerator()

$UsedParameters.ForEach({$ParametersHashtable.Add($_.Key, $_.Value)})

# Getting EventLogs
$EventLogsOutput = Get-GsxWinEventV1 @ParametersHashtable
$EventLogs = @(($EventLogsOutput.Events | ConvertFrom-Json))
$CommandCode = $EventLogsOutput.CommandCode
$CommandMessage = $EventLogsOutput.CommandMessage

# This object with Property ID set to -1 is the status of the command
$Output.AddResult(-1, $null, $null, $CommandCode, $CommandMessage)

if ([bool]$EventLogs) {
	foreach ($EventLog in $EventLogs) {
		$Output.AddResult(1,  $EventLog.RecordId, $EventLog.ActivityId,           $CommandCode, $CommandMessage) # String
		$Output.AddResult(2,  $EventLog.RecordId, $EventLog.Bookmark,             $CommandCode, $CommandMessage) # String
		$Output.AddResult(3,  $EventLog.RecordId, $EventLog.ContainerLog,         $CommandCode, $CommandMessage) # String
		$Output.AddResult(4,  $EventLog.RecordId, $EventLog.Id,                   $CommandCode, $CommandMessage) # Int32
		$Output.AddResult(5,  $EventLog.RecordId, $EventLog.Keywords,             $CommandCode, $CommandMessage) # Int64
		$Output.AddResult(6,  $EventLog.RecordId, $EventLog.KeywordsDisplayNames, $CommandCode, $CommandMessage) # String
		$Output.AddResult(7,  $EventLog.RecordId, $EventLog.Level,                $CommandCode, $CommandMessage) # Byte
		$Output.AddResult(8,  $EventLog.RecordId, $EventLog.LevelDisplayName,     $CommandCode, $CommandMessage) # String
		$Output.AddResult(9,  $EventLog.RecordId, $EventLog.LogName,              $CommandCode, $CommandMessage) # String
		$Output.AddResult(10, $EventLog.RecordId, $EventLog.MachineName,          $CommandCode, $CommandMessage) # String
		$Output.AddResult(11, $EventLog.RecordId, $EventLog.MatchedQueryIds,      $CommandCode, $CommandMessage) # String
		$Output.AddResult(12, $EventLog.RecordId, $EventLog.Message,              $CommandCode, $CommandMessage) # String
		$Output.AddResult(13, $EventLog.RecordId, $EventLog.Opcode,               $CommandCode, $CommandMessage) # In16
		$Output.AddResult(14, $EventLog.RecordId, $EventLog.OpcodeDisplayName,    $CommandCode, $CommandMessage) # String
		$Output.AddResult(15, $EventLog.RecordId, $EventLog.ProcessId,            $CommandCode, $CommandMessage) # Int32
		$Output.AddResult(16, $EventLog.RecordId, $EventLog.Properties,           $CommandCode, $CommandMessage) # String
		$Output.AddResult(17, $EventLog.RecordId, $EventLog.ProviderId,           $CommandCode, $CommandMessage) # String
		$Output.AddResult(18, $EventLog.RecordId, $EventLog.ProviderName,         $CommandCode, $CommandMessage) # String
		$Output.AddResult(19, $EventLog.RecordId, $EventLog.Qualifiers,           $CommandCode, $CommandMessage) # Int32
		$Output.AddResult(20, $EventLog.RecordId, $EventLog.RecordId,             $CommandCode, $CommandMessage) # Int64
		$Output.AddResult(21, $EventLog.RecordId, $EventLog.RelatedActivityId,    $CommandCode, $CommandMessage) # String
		$Output.AddResult(22, $EventLog.RecordId, $EventLog.Task,                 $CommandCode, $CommandMessage) # Int32
		$Output.AddResult(23, $EventLog.RecordId, $EventLog.TaskDisplayName,      $CommandCode, $CommandMessage) # String
		$Output.AddResult(24, $EventLog.RecordId, $EventLog.ThreadId,             $CommandCode, $CommandMessage) # Int32
		$Output.AddResult(25, $EventLog.RecordId, $EventLog.TimeCreated,          $CommandCode, $CommandMessage) # DateTime
		$Output.AddResult(26, $EventLog.RecordId, $EventLog.UserId,               $CommandCode, $CommandMessage) # String
		$Output.AddResult(27, $EventLog.RecordId, $EventLog.Version,              $CommandCode, $CommandMessage) # Byte
	}
}

# We will exit the PowerShell by returning this exact object
Return($Output)