#Requires -Version 4

# Set-StrictMode generates a terminating error when the content of an expression, script, or script block violates basic best-practice coding rules.
Set-StrictMode -Version 2.0

function Get-GsxADFSCertificateV1 {
	<#
		.SYNOPSIS
		This command will return the certificates from AD FS.

		.DESCRIPTION
		This command will return the certificates from AD FS.

		.LINK
		More information about the Get-AdfsCertificate cmdlet can be found here:
		https://docs.microsoft.com/en-us/powershell/module/adfs/get-adfscertificate?view=win10-ps

		.PARAMETER PowerShellLocal
		Type: [Bool]
		Default value: $false
        Description: Defines whether we use PowerShell locally or in a PSSession.

		.EXAMPLE
		Running the Get-GsxADFSCertificateV1 command

			PS> Get-GsxADFSCertificateV1

		.OUTPUTS
		Here is an example of the output:

			| Name           | Value                                                                                                   |
			| -------------- | ------------------------------------------------------------------------------------------------------- |
			| CommandCode    | 0                                                                                                       |
			| CommandMessage | Certificate(s) successfully retrieved                                                                   |
			| Certificates   | [ { "Thumbprint":"C54K0MRO4G5ZFKLOV399","NotAfter":"\/Date(1555827202000)\/","Subject":"CN=example" } ] |

		The output from this command will be an object that has the following properties available:

			| Properties     | Type   |
			| -------------- | ------ |
			| CommandCode    | Int    |
			| CommandMessage | String |
			| Certificates   | String |

		.NOTES
		Command codes and messages

			| CommandCode | CommandMessage                        | Certificates value            | Description                                          |
			| ----------- | ------------------------------------- | ----------------------------- | ---------------------------------------------------- |
			| 0           | Certificate(s) successfully retrieved | Certificate(s) as JSON string | Command successful with certificates retrieved.      |
			| 1           | Exception message                     | -                             | An issue occurred while retrieving the certificates. |
	#>

    [OutputType([psobject])]
    [cmdletbinding()]
	Param(
		[bool] $PowerShellLocal = $false
	)

    # List of the properties we want to retrieve from the certificates
	$PropertiesList = @(
		'Thumbprint'
		'NotAfter'
		'Subject'
	)

	$Output = [ordered]@{
		CommandCode    = $null
		CommandMessage = ""
		Certificates   = ""
	}

	# Storing current error action preference
	$OldErrorActionPreference = $ErrorActionPreference
	$ErrorActionPreference = 'Stop'

    try {

		$CommandParameters = @{
			ScriptBlock = { (Get-ADFSCertificate).Certificate }
		}

		if (!$PowerShellLocal) {
			$CommandParameters.Session = Get-PSSession
		}

		Write-Verbose "Retrieving certificates list..."
		$CertificatesRaw = Invoke-Command @CommandParameters

		$Certificates = $CertificatesRaw | Select-Object -Property $PropertiesList

		$Output.Certificates = (@($Certificates) | ConvertTo-Json -Depth 20 -Compress)

		Add-GsxOutputCodeAndMessage -Output $Output -Code 0 -Message "Certificate(s) successfully retrieved"
	}
	catch {
		$ErrorMessage = "An exception occurred: $($_.Exception.Message)"
		Write-Warning $ErrorMessage
		Add-GsxOutputCodeAndMessage -Output $Output -Code 1 -Message $ErrorMessage
	}

	$ErrorActionPreference = $OldErrorActionPreference

	$Output
}

function Add-GsxOutputCodeAndMessage {
    param(
        [Parameter( Mandatory = $true )] [System.Collections.Specialized.OrderedDictionary] $Output,
        [Parameter( Mandatory = $true )] [int] $Code,
        [Parameter( Mandatory = $true )] [string[]] $Message
    )
    $Output.CommandCode = $Code
    $Output.CommandMessage = ($Message | Select-Object -Unique) -join "`n"
}

Export-ModuleMember -Function 'Get-GsxADFSCertificateV1'