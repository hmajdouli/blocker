#Requires -Version 4

# Set-StrictMode generates a terminating error when the content of an expression, script, or script block violates basic best-practice coding rules.
Set-StrictMode -Version 2.0

function Get-GsxADFSWinEventV1 {
	<#
		.SYNOPSIS
		This command will return the following Win events from 'AD FS/Admin' event log:
		- 1201
		- 1203
		- 1205
		- 1207

		.DESCRIPTION
		This command will return the following Win events from 'AD FS/Admin' event log:
		- 1201 (Application Token Failure)
		- 1203 (Fresh Credential Validation Error)
		- 1205 (Password Change Request Error)
		- 1207 (Sign Out Failure)

		.LINK
		More information about the Get-WinEvent cmdlet can be found here:
		https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.diagnostics/get-winevent?view=powershell-4.0

		More information about the statistics retrieved:
		https://docs.microsoft.com/en-us/windows-server/identity/ad-fs/troubleshooting/ad-fs-tshoot-logging#types-of-events

		.PARAMETER PowerShellLocal
		Type: [Bool]
		Default value: $false
        Description: Defines whether we use PowerShell locally or in a PSSession.

		.EXAMPLE
		Running the Get-GsxADFSWinEventV1 command

			PS> Get-GsxADFSWinEventV1

		.OUTPUTS
		Here is an example of the output:

			| Name           | Value                                              |
			| -------------- | -------------------------------------------------- |
			| CommandCode    | 0                                                  |
			| CommandMessage | ADFS Win events successfully retrieved             |
			| Disks          | [ { "RecordId":7331,"ProviderName":"AD FS" ... } ] |

		The output from this command will be an object that has the following properties available:

			| Properties     | Type   |
			| -------------- | ------ |
			| CommandCode    | Int    |
			| CommandMessage | String |
			| ADFSWinEvents  | String |

		.NOTES
		Command codes and messages

			| CommandCode | CommandMessage                         | ADFSWinEvents value            | Description                                                                                                                                                                                    |
			| ----------- | -------------------------------------- | ------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
			| 0           | ADFS Win events successfully retrieved | ADFS Win events as JSON string | Command is success with ADFS Win events retrieved                                                                                                                                              |
			| 1           | ADFS Win events successfully retrieved | ADFS Win events as JSON string | Scan Date file is not valid or does not exist                                                                                                                                                  |
			| 2           | Exception Message                      | -                              | An issue occurred while retrieving the ADFS Win events or when no ADFS Win events found                                                                                                        |
			| 3           | Exception Message                      | -                              | Scan Date file is not valid or does not exist - An issue occurred while retrieving the ADFS Win events                                                                                         |
			| 4           | Exception Message                      | -                              | Failed to read/write the Scan Date file                                                                                                                                                        |
			| 5           | Exception Message                      | -                              | Scan Date file is not valid or does not exist - Failed to read/write the Scan Date file                                                                                                        |
			| 6           | Exception Message                      | -                              | An issue occurred while retrieving the ADFS Win events - Failed to read/write the Scan Date file                                                                                               |
			| 7           | Exception Message                      | -                              | Scan Date file is not valid or does not exist - An issue occurred while retrieving the ADFS Win events - Failed to read/write the Scan Date file                                               |
			| 8           | Exception Message                      | -                              | Failed to update the Scan Date file content                                                                                                                                                    |
			| 9           | Exception Message                      | -                              | Scan Date file is not valid or does not exist - Failed to update the Scan Date file content                                                                                                    |
			| 10          | Exception Message                      | -                              | An issue occurred while retrieving the ADFS Win events - Failed to update the Scan Date file content                                                                                           |
			| 11          | Exception Message                      | -                              | Scan Date file is not valid or does not exist - An issue occurred while retrieving the ADFS Win events - Failed to update the Scan Date file content                                           |
			| 12          | Exception Message                      | -                              | Failed to read/write the Scan Date file - Failed to update the Scan Date file content                                                                                                          |
			| 13          | Exception Message                      | -                              | Scan Date file is not valid or does not exist - Failed to read/write the Scan Date file - Failed to update the Scan Date file content                                                          |
			| 14          | Exception Message                      | -                              | An issue occurred while retrieving the ADFS Win events - Failed to read/write the Scan Date file - Failed to update the Scan Date file content                                                 |
			| 15          | Exception Message                      | -                              | Scan Date file is not valid or does not exist - An issue occurred while retrieving the ADFS Win events - Failed to read/write the Scan Date file - Failed to update the Scan Date file content |
    #>

    [OutputType([psobject])]
    [cmdletbinding()]
	Param(
		[bool] $PowerShellLocal = $false
	)

	begin {
		$ScanDateFilePath = "$PSScriptRoot\ScanDate.txt"

		[Array] $ADFSWinEvents = @()

		$Output = [ordered]@{
			CommandCode    = $null
			CommandMessage = ""
			ADFSWinEvents  = ""
		}

		[int] $CommandCode = 0

		$Flags = @{
			None                           = 0
			PreviousScanDateFileIssue      = 1
			EventLogIssue                  = 2
			CurrentScanDateFileUpdateIssue = 4
			FinalScanDateFileUpdateIssue   = 8
		}

		$CommandMessageList = @()

		$OldErrorActionPreference = $ErrorActionPreference
		$ErrorActionPreference = 'Stop'
	}

	process {

		try {

			Write-Verbose "Checking if the scan date file exists with the valid content ..."
			[bool] $FileExists = ( Test-Path -LiteralPath $ScanDateFilePath )

			if ( $FileExists ) {
				Write-Verbose "File exists at: $ScanDateFilePath"
				$IsScanDateFileValid = Test-GsxScanDateFile -ScanDateFilePath $ScanDateFilePath

				if ( -not $IsScanDateFileValid ) {
					Write-Verbose 'File content is not valid'
					$CommandCode        += $Flags.PreviousScanDateFileIssue
					$CommandMessageList += 'Previous scan date file is not valid'

					Write-Verbose "Writing date in $ScanDateFilePath ..."
					Set-GsxScanDateToFile -ScanDateFilePath $ScanDateFilePath -ErrorAction Stop
				}
				else {
					Write-Verbose "File content is valid"
				}
			}
			else {
				Write-Verbose "File not found at $ScanDateFilePath"
				$CommandCode += $Flags.PreviousScanDateFileIssue

				Write-Verbose 'Creating file ...'
				New-Item -Path $ScanDateFilePath -ItemType File -Force -ErrorAction Stop > $null
				Write-Verbose 'File created'

				Write-Verbose "Writing date in $ScanDateFilePath ..."
				Set-GsxScanDateToFile -ScanDateFilePath $ScanDateFilePath -ErrorAction Stop
			}

			$PreviousScanDate = Get-GsxPreviousScanDate -ScanDateFilePath $ScanDateFilePath

			if ( $PreviousScanDate ) {

				$ADFSWinEventsQuery = @"
				<QueryList>
				<Query Id="0" Path="ad fs/admin">
					<Select Path="ad fs/admin">*[
						( (System/EventID=1201) or (System/EventID=1203) or (System/EventID=1205) or (System/EventID=1207) ) and
						(System/TimeCreated[@SystemTime&gt;='$PreviousScanDate'])]
					</Select>
				</Query>
			</QueryList>
"@

				$FilterXmlQuery = @{ FilterXml = $ADFSWinEventsQuery }

				$CommandParameters = @{
					ScriptBlock = {param ($FilterXmlQuery) (Get-WinEvent @FilterXmlQuery)}
					ArgumentList = $FilterXmlQuery
				}

				if (!$PowerShellLocal) {
					$CommandParameters.Session = Get-PSSession
				}

				Write-Verbose "Getting ADFS Win events ..."
				$ADFSWinEvents = Invoke-Command @CommandParameters -ErrorAction SilentlyContinue -ErrorVariable ADFSWinEventsError

				if ( $ADFSWinEvents ) {
					$Output.ADFSWinEvents = ( @($ADFSWinEvents) | ConvertTo-Json -Depth 10 )
					$CommandMessageList += "ADFS Win events successfully retrieved"
				}
				elseif ( $ADFSWinEventsError ) {
					$ADFSWinEventsErrorMessage = $ADFSWinEventsError.Exception.Message
					$CommandMessageList += "Error occurred while getting ADFS Win events: $ADFSWinEventsErrorMessage"
					$CommandCode += $Flags.EventLogIssue
				}
				else {
					$CommandMessageList += "No match found in the ADFS Win events"
				}
			}

			Set-GsxScanDateToFile -ScanDateFilePath $ScanDateFilePath -ErrorAction SilentlyContinue -ErrorVariable ScanDateFileUpdateError

            if ( -not ([string]::IsNullOrEmpty($ScanDateFileUpdateError)) ) {
                $Exception = $ScanDateFileUpdateError[0].Message
                $ErrorMessage = "Error occurred while writing the current date in the file: $Exception"
                Write-Warning $ErrorMessage
                $CommandMessageList += $ErrorMessage
                $CommandCode        += $Flags.FinalScanDateFileUpdateIssue
            }
		}
        catch [System.UnauthorizedAccessException], [System.IO.DirectoryNotFoundException], [System.IO.IOException] {
            if ($_.Exception.PSObject.Members.name -contains "InnerException" -and $_.Exception.InnerException) {
                $Exception = $_.Exception.InnerException.Message
            }
            else {
                $Exception = $_.Exception.Message
            }

            $ErrorMessage = "An exception occurred while reading/writing to file: $Exception"
            Write-Warning $ErrorMessage
            $CommandMessageList += $ErrorMessage
            $CommandCode        += $Flags.CurrentScanDateFileUpdateIssue
        }
        catch {
            $ErrorMessage = "An exception occurred while getting ADFS Win events:`n$($_.Exception.Message)"
            Write-Warning $ErrorMessage
            $CommandMessageList += $ErrorMessage
            $CommandCode        += $Flags.EventLogIssue
        }
	}

    end {
        $Output.CommandCode = $CommandCode
        [array]::Reverse($CommandMessageList)
        $Output.CommandMessage = $CommandMessageList -join "`n`n"

        Write-Verbose 'Printing result ...'
		$Output

		$ErrorActionPreference = $OldErrorActionPreference
    }
}

function Get-GsxPreviousScanDate {
    param (
        [Parameter( Mandatory = $true )] $ScanDateFilePath
    )
    try {
        $PreviousScanDate = ( Get-Content -LiteralPath $ScanDateFilePath -Raw -ErrorAction Stop )
        [datetime] $PreviousScanDate
    }
    catch {
        $null
    }
}

function Test-GsxScanDateFile {
    param (
        [Parameter( Mandatory = $true )] $ScanDateFilePath
    )

    $File = Get-Item $ScanDateFilePath
    $Stream = $File.Open('Open', [System.IO.FileAccess]::ReadWrite)
    $Stream.Close()

    [string] $FileContent = ( Get-Content -Path $ScanDateFilePath -Raw -ErrorAction Stop )
    if ( [string]::IsNullOrEmpty($FileContent) ) { return $false } else { $FileContent = $FileContent.Trim() }

    [int]  $FileLines = ( $FileContent | Measure-Object -Line -ErrorAction SilentlyContinue ) | Select-Object -ExpandProperty Lines
    [bool] $FileContentNotValid = (( $FileLines -ne 1 ) -or !( Test-GsxStringIsDatetime -Value $FileContent))

    if ( $FileContentNotValid ) {
        $false
    }
    else {
        $true
    }
}

function Test-GsxStringIsDatetime {
    param (
        [string] $Value
    )
    try {
        [DateTime] $Value > $null
        $true
    }
    catch {
        $false
    }
}

function Set-GsxScanDateToFile {
    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter( Mandatory = $true )] $ScanDateFilePath
    )
    if ( $PSCmdlet.ShouldProcess($ScanDateFilePath) ) {
        $NewScanDate = (Get-Date).ToUniversalTime()

        Set-Content -Path $ScanDateFilePath -Value ( $NewScanDate.ToString('o') ) -Encoding Ascii -ErrorAction Stop

        Write-Verbose "Content has been successfully written in the file $ScanDateFilePath"
    }
}

Export-ModuleMember -Function 'Get-GsxADFSWinEventV1'