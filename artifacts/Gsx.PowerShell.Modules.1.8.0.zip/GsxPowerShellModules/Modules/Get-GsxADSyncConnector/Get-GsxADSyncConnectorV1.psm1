#Requires -Version 4

# Set-StrictMode generates a terminating error when the content of an expression, script, or script block violates basic best-practice coding rules.
Set-StrictMode -Version 2.0

function Get-GsxADSyncConnectorV1 {
	<#
		.SYNOPSIS
		This command will return all the AD Sync connectors.

		.DESCRIPTION
		This command will return all the AD Sync connectors.

		.LINK

		.PARAMETER PowerShellLocal
		Type: [Bool]
		Default value: $false
        Description: Defines whether we use PowerShell locally or in a PSSession.

		.EXAMPLE
		Running the Get-GsxADSyncConnectorV1 command

			PS> Get-GsxADSyncConnectorV1

		.OUTPUTS
		Here is an example of the output:

			| Name           | Value                                                                                                               |
			| -------------- | ------------------------------------------------------------------------------------------------------------------- |
			| CommandCode    | 0                                                                                                                   |
			| CommandMessage | Connector(s) successfully retrieved                                                                                 |
			| Connectors     | [ { "Name":"connector","ConnectorTypeName":"AD","Type":"AD","LastModificationTime":"\/Date(1546297200000)\/"} ... ] |

		The output from this command will be an object that has the following properties available:

			| Properties     | Type   |
			| -------------- | ------ |
			| CommandCode    | Int    |
			| CommandMessage | String |
			| Connectors     | String |

		.NOTES
		Command codes and messages

			| CommandCode | CommandMessage                      | Connectors value            | Description                                          |
			| ----------- | ----------------------------------- | --------------------------- | ---------------------------------------------------- |
			| 0           | Connector(s) successfully retrieved | Connector(s) as JSON string | Command successful with connectors retrieved.        |
			| 1           | Exception message                   | -                           | An issue occurred while retrieving the connector(s). |
	#>

    [OutputType([psobject])]
    [cmdletbinding()]
	Param(
		[bool] $PowerShellLocal = $false
	)

	$Output = [ordered]@{
		CommandCode    = $null
		CommandMessage = ""
		Connectors     = ""
	}

	$PropertiesList = @{
		Property = @(
			'Name'
			'ConnectorTypeName'
			'Type'
			'LastModificationTime'
			'ExportAdds'
			'ExportUpdates'
			'ExportDeletes'
			'TotalConnectors'
		)
	}

	# Storing current error action preference
	$OldErrorActionPreference = $ErrorActionPreference
	$ErrorActionPreference = 'Stop'

    try {
		$CommandParameters = @{
			ScriptBlock = {

				param($PropertiesList)

				$ADSyncConnectors = Get-ADSyncConnector | Select-Object @PropertiesList

				foreach ($Connector in $ADSyncConnectors) {
					$ConnectorStatistics = Get-ADSyncConnectorStatistics -ConnectorName $Connector.Name

					$ConnectorObject = $ADSyncConnectors | Where-Object { $_.Name -eq $Connector.Name }
					$ConnectorObject.ExportAdds      =  $ConnectorStatistics.ExportAdds
					$ConnectorObject.ExportUpdates   =  $ConnectorStatistics.ExportUpdates
					$ConnectorObject.ExportDeletes   =  $ConnectorStatistics.ExportDeletes
					$ConnectorObject.TotalConnectors =  $ConnectorStatistics.TotalConnectors
				}

				return $ADSyncConnectors
			}
		}

		$CommandParameters.ArgumentList = $PropertiesList

		if (!$PowerShellLocal) {
			$CommandParameters.Session = Get-PSSession
		}

		Write-Verbose "Retrieving connectors list..."
		$Connectors = Invoke-Command @CommandParameters | Select-Object @PropertiesList

		$Output.Connectors = (@($Connectors) | ConvertTo-Json -Depth 20 -Compress)

		Add-GsxOutputCodeAndMessage -Output $Output -Code 0 -Message "Connector(s) successfully retrieved"
	}
	catch {
		$ErrorMessage = "An exception occurred: $($_.Exception.Message)"
		Write-Warning $ErrorMessage
		Add-GsxOutputCodeAndMessage -Output $Output -Code 1 -Message $ErrorMessage
	}

	$ErrorActionPreference = $OldErrorActionPreference

	$Output
}

function Add-GsxOutputCodeAndMessage {
    param(
        [Parameter( Mandatory = $true )] [System.Collections.Specialized.OrderedDictionary] $Output,
        [Parameter( Mandatory = $true )] [int] $Code,
        [Parameter( Mandatory = $true )] [string[]] $Message
    )
    $Output.CommandCode = $Code
    $Output.CommandMessage = ($Message | Select-Object -Unique) -join "`n"
}

Export-ModuleMember -Function 'Get-GsxADSyncConnectorV1'