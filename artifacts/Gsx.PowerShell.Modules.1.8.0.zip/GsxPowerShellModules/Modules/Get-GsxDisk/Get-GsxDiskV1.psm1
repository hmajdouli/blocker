#Requires -Version 4

# Set-StrictMode generates a terminating error when the content of an expression, script, or script block violates basic best-practice coding rules.
Set-StrictMode -Version 2.0

function Get-GsxDiskV1 {
    <#
		.SYNOPSIS
		This command will return the local disks information.

		.DESCRIPTION
		This command will return the local disks information.
		Units used for the total size and free space of the disks are in GigaBytes.
		You can find below some information regarding the statistics retrieved:
		- A volume that has no DriveLetter is a MountPoint volume
		- A volume label is optional, so its value can be $null

		.LINK
		More information about the Win32_Volume class can be found here:
		https://msdn.microsoft.com/en-us/library/aa394515(v=vs.85).aspx#properties

		.PARAMETER PowerShellLocal
		Type: [Bool]
		Default value: $false
        Description: Defines whether we use PowerShell locally or in a PSSession.

		.EXAMPLE
		Running the Get-GsxDiskV1 command

			PS> Get-GsxDiskV1

		.OUTPUTS
		Here is an example of the output:

			| Name           | Value                                                    |
			| -------------- | -------------------------------------------------------- |
			| CommandCode    | 0                                                        |
			| CommandMessage | Disk(s) successfully retrieved                           |
			| Disks          | [ { "Name":"C:\\","Label":"C:","DriveLetter":"C:"... } ] |

		The output from this command will be an object that has the following properties available:

			| Properties     | Type   |
			| -------------- | ------ |
			| CommandCode    | Int    |
			| CommandMessage | String |
			| Disks          | String |

		.NOTES
		Command codes and messages

			| CommandCode | CommandMessage                 | Disks value            | Description                                                                                                                           |
			| ----------- | ------------------------------ | ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
			| 0           | Disk(s) successfully retrieved | Disk(s) as JSON string | Command successful with disk(s) retrieved.                                                                                            |
			| 1           | Unknown exception message      | Empty string           | When an unknown exception occurred.                                                                                                   |
			| 2           | CIM Exception message          | Empty string           | When a CIM exception occurred. This exception can occur when the Winmgmt (Windows Management Instrumentation) service is not running. |
	#>

    [OutputType([psobject])]
    [cmdletbinding()]
	Param(
		[bool] $PowerShellLocal = $false
	)

	begin {

		# Converting the sizes in GigaBytes
		$TotalSizeInGigaBytes  = @{ Label = "TotalSizeInGigaBytes";  Expression = { [double][System.Math]::Round(($_.Capacity / 1GB), 12) } }
		$FreeSpaceInGigaBytes  = @{ Label = "FreeSpaceInGigaBytes";  Expression = { [double][System.Math]::Round(($_.FreeSpace / 1GB), 12) } }
		$FreeSpaceInPercentage = @{ Label = "FreeSpaceInPercentage"; Expression = { [double][System.Math]::Round(((($_.FreeSpace / 1GB) / ($_.Capacity / 1GB)) * 100), 12) } }

		# Checking if the volume is a MountPoint
		$IsMountPoint          = @{ Label = "IsMountPoint"; Expression = { [bool]([string]::IsNullOrEmpty($_.DriveLetter)) } }

		# List of the properties we want to retrieve from the disks
		$PropertiesList = @(
			'Name'
			'Label'
			'DriveLetter'
			'FileSystem'
			$TotalSizeInGigaBytes
			$FreeSpaceInGigaBytes
			$FreeSpaceInPercentage
			$IsMountPoint
		)

		$Output = [ordered]@{
			CommandCode    = $null
			CommandMessage = ""
			Disks          = ""
		}

		# Storing current error action preference
		$OldErrorActionPreference = $ErrorActionPreference
		$ErrorActionPreference = 'Stop'

	}

	process {

		try {
			$CimInstanceParameters = @{
				ClassName = 'Win32_Volume'
				Filter = "DriveType = 3 AND SystemVolume = False"
			}

			$CommandParameters = @{
				ScriptBlock = {param ($CimInstanceParameters) (Get-CimInstance @CimInstanceParameters)}
				ArgumentList = $CimInstanceParameters
			}

			if (!$PowerShellLocal) {
				$CommandParameters.Session = Get-PSSession
			}

			Write-Verbose "Retrieving volumes list..."
			$Volumes = Invoke-Command @CommandParameters

			Write-Verbose "Retrieving disk(s) list..."
			$Disks = $Volumes | Select-Object -Property $PropertiesList | Sort-Object -Property Name

			$Output.Disks = (@($Disks) | ConvertTo-Json -Depth 20 -Compress)

			Add-GsxOutputCodeAndMessage -Output $Output -Code 0 -Message "Disk(s) successfully retrieved"
		}
		catch [Microsoft.Management.Infrastructure.CimException] {
			Write-Warning "An exception occurred: $($_.Exception.Message)"
			Add-GsxOutputCodeAndMessage -Output $Output -Code 2 -Message $_.Exception.Message
		}
		catch {
			$ErrorMessage = "An exception occurred: $($_.Exception.Message)"
			Write-Warning $ErrorMessage
			Add-GsxOutputCodeAndMessage -Output $Output -Code 1 -Message $ErrorMessage
		}
	}

	end {
		$ErrorActionPreference = $OldErrorActionPreference
		$Output
	}
}

function Add-GsxOutputCodeAndMessage {
    param(
        [Parameter( Mandatory = $true )] [System.Collections.Specialized.OrderedDictionary] $Output,
        [Parameter( Mandatory = $true )] [int] $Code,
        [Parameter( Mandatory = $true )] [string[]] $Message
    )
    $Output.CommandCode = $Code
    $Output.CommandMessage = ($Message | Select-Object -Unique) -join "`n"
}

Export-ModuleMember -Function Get-GsxDiskV1