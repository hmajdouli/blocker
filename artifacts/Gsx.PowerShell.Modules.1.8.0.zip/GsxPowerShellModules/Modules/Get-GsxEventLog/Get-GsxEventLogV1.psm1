#Requires -Version 4

# Set-StrictMode generates a terminating error when the content of an expression, script, or script block violates basic best-practice coding rules.
Set-StrictMode -Version 2.0

function Get-GsxEventLogV1 {
    <#
		.SYNOPSIS
		This command will return a list of the event logs from a computer.

		.DESCRIPTION
		This command will return a list of the event logs from a computer.

		.LINK
		More information about the Get-EventLog command:
		https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.management/get-eventlog?view=powershell-5.1

		.PARAMETER LogName
        Type: [String]
        Description: Specifies the name of one event log.

		.PARAMETER Index
        Type: [Int[]]
        Description: Specifies the index values to get from the event log. The parameter accepts a comma-separated string of values.

		.PARAMETER EntryType
        Type: [String[]]
        Description: Specifies, as a string array, the entry type of the events that this cmdlet gets.

		.PARAMETER InstanceId
        Type: [String[]]
        Description: Specifies the Instance IDs to get from the event log. The parameter accepts a comma-separated string of values.

		.PARAMETER Message
        Type: [String]
        Description: Specifies a string in the event message. You can use this parameter to search for messages that contain certain words or phrases. Wildcards are permitted.

		.PARAMETER Category
        Type: [String]
        Description: Specifies the text associated with the CategoryNumber property for this entry.

		.PARAMETER CategoryNumber
        Type: [Int16]
        Description: Specifies the category number of the event log entry.

		.PARAMETER Source
        Type: [String[]]
        Description: Specifies, as a string array, sources that were written to the log that this cmdlet gets. Wildcards are permitted.

		.PARAMETER Newest
        Type: [Int]
        Default value: 100
        Description: Returns the specified number of events beginning with the newest events.

		.PARAMETER PowerShellLocal
        Type: [Bool]
        Default value: $false
        Description: Defines whether we use PowerShell locally or in a PSSession.

		.EXAMPLE
		Running the Get-GsxEventLogV1 command

            PS> Get-GsxEventLogV1 -LogName Application -Newest 10

        .OUTPUTS
        Here is an example of the output:

            | Name           | Value                                                                                                                                  |
            | -------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
            | CommandCode    | 0                                                                                                                                      |
            | CommandMessage | Event log(s) successfully retrieved                                                                                                    |
            | Logs           | [ { "MachineName": "GSX", "Data": [], "Index": 7295, "Category": "General", "CategoryNumber": 1, "EventID": 916, "EntryType": 4... } ] |


        The output from this command will be an object that has the following properties available:

            | Properties     | Type   |
            | -------------- | ------ |
            | CommandCode    | Int    |
            | CommandMessage | String |
            | Logs           | String |

		.NOTES
        Command codes and messages

            | CommandCode | CommandMessage                      | Logs                                     | Description                                                                                                                                                                        |
            | ----------- | ----------------------------------- | ---------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
            | 0           | Event log(s) successfully retrieved | Event log(s) as JSON string if any found | Command is success even when no logs are found                                                                                                                                     |
            | 1           | Event log(s) successfully retrieved | Event log(s) as JSON string if any found | Scan Date file is not valid or does not exist                                                                                                                                      |
            | 2           | Exception Message                   | -                                        | An issue occurred while retrieving the logs                                                                                                                                         |
            | 3           | Exception Message                   | -                                        | Scan Date file is not valid or does not exist - An issue occurred while retrieving the logs                                                                                         |
            | 4           | Exception Message                   | -                                        | Failed to read/write the Scan Date file                                                                                                                                            |
            | 5           | Exception Message                   | -                                        | Scan Date file is not valid or does not exist - Failed to read/write the Scan Date file                                                                                            |
            | 6           | Exception Message                   | -                                        | An issue occurred while retrieving the logs - Failed to read/write the Scan Date file                                                                                               |
            | 7           | Exception Message                   | -                                        | Scan Date file is not valid or does not exist - An issue occurred while retrieving the logs - Failed to read/write the Scan Date file                                               |
            | 8           | Exception Message                   | -                                        | Failed to update the Scan Date file content                                                                                                                                        |
            | 9           | Exception Message                   | -                                        | Scan Date file is not valid or does not exist - Failed to update the Scan Date file content                                                                                        |
            | 10          | Exception Message                   | -                                        | An issue occurred while retrieving the logs - Failed to update the Scan Date file content                                                                                           |
            | 11          | Exception Message                   | -                                        | Scan Date file is not valid or does not exist - An issue occurred while retrieving the logs - Failed to update the Scan Date file content                                           |
            | 12          | Exception Message                   | -                                        | Failed to read/write the Scan Date file - Failed to update the Scan Date file content                                                                                              |
            | 13          | Exception Message                   | -                                        | Scan Date file is not valid or does not exist - Failed to read/write the Scan Date file - Failed to update the Scan Date file content                                              |
            | 14          | Exception Message                   | -                                        | An issue occurred while retrieving the logs - Failed to read/write the Scan Date file - Failed to update the Scan Date file content                                                 |
            | 15          | Exception Message                   | -                                        | Scan Date file is not valid or does not exist - An issue occurred while retrieving the logs - Failed to read/write the Scan Date file - Failed to update the Scan Date file content |
	#>

    [OutputType([psobject])]
    [cmdletbinding()]
    Param(
        $LogName,
        $Index,
        $EntryType,
        $InstanceId,
        $Message,
        $Category,
        $CategoryNumber,
        $Source,
        $Newest = 100,
        [bool] $PowerShellLocal = $false
    )

    begin {
        $ScanDateFilePath = "$PSScriptRoot\ScanDate.txt"

        [Array] $Logs = @()

        $Output = [ordered]@{
            CommandCode    = $null
            CommandMessage = ""
            Logs           = ""
        }

        [int] $CommandCode = 0

        $Flags = @{
            None                           = 0
            PreviousScanDateFileIssue      = 1
            EventLogIssue                  = 2
            CurrentScanDateFileUpdateIssue = 4
            FinalScanDateFileUpdateIssue   = 8
        }

        $CommandMessageList = @()
    }

    process {

        try {
            Write-Verbose "Checking if the scan date file exists with the valid content ..."
            [bool] $FileExists = ( Test-Path -LiteralPath $ScanDateFilePath )

            if ( $FileExists ) {
                Write-Verbose "File exists at: $ScanDateFilePath"
                $IsScanDateFileValid = Test-GsxScanDateFile -ScanDateFilePath $ScanDateFilePath

                if ( -not $IsScanDateFileValid ) {
                    Write-Verbose 'File content is not valid'
                    $CommandCode        += $Flags.PreviousScanDateFileIssue
                    $CommandMessageList += 'Previous scan date file is not valid'

                    Write-Verbose "Writing date in $ScanDateFilePath ..."
                    Set-GsxScanDateToFile -ScanDateFilePath $ScanDateFilePath -ErrorAction Stop
                }
                else {
                    Write-Verbose "File content is valid"
                }
            }
            else {
                Write-Verbose "File not found at $ScanDateFilePath"
                $CommandCode += $Flags.PreviousScanDateFileIssue

                Write-Verbose 'Creating file ...'
                New-Item -Path $ScanDateFilePath -ItemType File -Force -ErrorAction Stop > $null
                Write-Verbose 'File created'

                Write-Verbose "Writing date in $ScanDateFilePath ..."
                Set-GsxScanDateToFile -ScanDateFilePath $ScanDateFilePath -ErrorAction Stop
            }

            $PreviousScanDate = Get-GsxPreviousScanDate -ScanDateFilePath $ScanDateFilePath

            if ( $PreviousScanDate ) {
                $UsedParameters = $PSBoundParameters

                $GetEventLogAndFilterParameters = Get-GsxEventLogParameter -UsedParameters $UsedParameters
                $GetEventLogParameters          = $GetEventLogAndFilterParameters.GetEventLogParameters
                $GetEventLogFilters             = $GetEventLogAndFilterParameters.Filter

                $GetEventLogParameters.After = $PreviousScanDate

                $WhereBlock = Get-GsxEventLogFilter -Filter $GetEventLogFilters

                if ($WhereBlock) {
                    $ArgumentList = $GetEventLogParameters, $WhereBlock
                    $ScriptBlock  = { param ($GetEventLogParameters, $WhereBlock) Get-EventLog @GetEventLogParameters | Where-Object $WhereBlock }
                }
                else {
                    $ArgumentList = $GetEventLogParameters
                    $ScriptBlock  = { param ($GetEventLogParameters) Get-EventLog @GetEventLogParameters }
                }

                $CommandParameters = @{
                    ScriptBlock  = $ScriptBlock
                    ArgumentList = $ArgumentList
                }

                if (!$PowerShellLocal) {
                    $CommandParameters.Session = Get-PSSession
                }

                Write-Verbose "Getting event logs ..."
                $Logs = Invoke-Command @CommandParameters -ErrorAction SilentlyContinue -ErrorVariable LogsError

                if ( $Logs ) {
                    $Output.Logs = ( @($Logs) | ConvertTo-Json -Depth 10 )
                    $CommandMessageList += "Event log(s) successfully retrieved"
                }
                elseif ( $LogsError ) {
                    $LogsErrorMessage = $LogsError.Exception.Message
                    $CommandMessageList += "Error occurred while getting logs: $LogsErrorMessage"
                    $CommandCode += $Flags.EventLogIssue
                }
                else {
                    $CommandMessageList += "No match found in the event logs"
                }
            }

            Set-GsxScanDateToFile -ScanDateFilePath $ScanDateFilePath -ErrorAction SilentlyContinue -ErrorVariable ScanDateFileUpdateError

            if ( -not ([string]::IsNullOrEmpty($ScanDateFileUpdateError)) ) {
                $Exception = $ScanDateFileUpdateError[0].Message
                $ErrorMessage = "Error occurred while writing the current date in the file: $Exception"
                Write-Warning $ErrorMessage
                $CommandMessageList += $ErrorMessage
                $CommandCode        += $Flags.FinalScanDateFileUpdateIssue
            }
        }
        catch [System.UnauthorizedAccessException], [System.IO.DirectoryNotFoundException], [System.IO.IOException] {
            if ($_.Exception.PSObject.Members.name -contains "InnerException" -and $_.Exception.InnerException) {
                $Exception = $_.Exception.InnerException.Message
            }
            else {
                $Exception = $_.Exception.Message
            }

            $ErrorMessage = "An exception occurred while reading/writing to file: $Exception"
            Write-Warning $ErrorMessage
            $CommandMessageList += $ErrorMessage
            $CommandCode        += $Flags.CurrentScanDateFileUpdateIssue
        }
        catch {
            $ErrorMessage = "An exception occurred while getting logs:`n$($_.Exception.Message)"
            Write-Warning $ErrorMessage
            $CommandMessageList += $ErrorMessage
            $CommandCode        += $Flags.EventLogIssue
        }
    }
    end {
        $Output.CommandCode = $CommandCode
        [array]::Reverse($CommandMessageList)
        $Output.CommandMessage = $CommandMessageList -join "`n`n"

        Write-Verbose 'Printing result ...'
        $Output
    }
}

function Get-GsxPreviousScanDate {
    param (
        [Parameter( Mandatory = $true )] $ScanDateFilePath
    )
    try {
        $PreviousScanDate = ( Get-Content -LiteralPath $ScanDateFilePath -Raw -ErrorAction Stop )
        [datetime] $PreviousScanDate
    }
    catch {
        $null
    }
}

function Test-GsxScanDateFile {
    param (
        [Parameter( Mandatory = $true )] $ScanDateFilePath
    )

    $File = Get-Item $ScanDateFilePath
    $Stream = $File.Open('Open', [System.IO.FileAccess]::ReadWrite)
    $Stream.Close()

    [string] $FileContent = ( Get-Content -Path $ScanDateFilePath -Raw -ErrorAction Stop )
    if ( [string]::IsNullOrEmpty($FileContent) ) { return $false } else { $FileContent = $FileContent.Trim() }

    [int]  $FileLines = ( $FileContent | Measure-Object -Line -ErrorAction SilentlyContinue ) | Select-Object -ExpandProperty Lines
    [bool] $FileContentNotValid = (( $FileLines -ne 1 ) -or !( Test-GsxStringIsDatetime -Value $FileContent))

    if ( $FileContentNotValid ) {
        $false
    }
    else {
        $true
    }
}

function Test-GsxStringIsDatetime {
    param (
        [string] $Value
    )
    try {
        [DateTime] $Value > $null
        $true
    }
    catch {
        $false
    }
}

function Set-GsxScanDateToFile {
    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter( Mandatory = $true )] $ScanDateFilePath
    )
    if ( $PSCmdlet.ShouldProcess($ScanDateFilePath) ) {
        $NewScanDate = (Get-Date).ToUniversalTime()

        Set-Content -Path $ScanDateFilePath -Value ( $NewScanDate.ToString('o') ) -Encoding Ascii -ErrorAction Stop

        Write-Verbose "Content has been successfully written in the file $ScanDateFilePath"
    }
}

function Get-GsxEventLogParameter {
    param(
        $UsedParameters
    )

    if ( $null -eq $UsedParameters ) { return $null }

    $GetEventLogParameters = @{ 'After' = $null }
    $FilterParameters = @{}

    # Setting the Logname parameter to $null if not specified
    if ( -not ($UsedParameters.ContainsKey('LogName')) -or ($null -eq $UsedParameters.LogName)) {
        $GetEventLogParameters.Add('LogName', $null)
    }

    # Adding parameters to $GetEventLogParameters dict except Category and CategoryNumber
    foreach ( $Parameter in $UsedParameters.GetEnumerator() ) {
        if ( ([string]::IsNullOrEmpty($Parameter.Value)) -or ($Parameter.Key -eq 'PowerShellLocal') ) {
            continue
        }
        elseif ( ($Parameter.Key -notlike 'Category') -and ($Parameter.Key -notlike 'CategoryNumber') -and ($Parameter.Key -notlike 'InstanceId') ) {
            $GetEventLogParameters.Add($Parameter.Key, $Parameter.Value)
        }
        elseif ($Parameter.Key -like 'InstanceId') {
            $InstanceIdValue = $Parameter.Value | ConvertFrom-Json
            $GetEventLogParameters.Add($Parameter.Key, $InstanceIdValue)
        }
        else {
            $FilterParameters.Add($Parameter.Key, $Parameter.Value)
        }
    }
    [hashtable]@{ 'Filter' = $FilterParameters; 'GetEventLogParameters' = $GetEventLogParameters }
}

function Get-GsxEventLogFilter {
    [OutputType([scriptblock])]
    [cmdletbinding()]
    Param(
        [hashtable] $Filter
    )
    $FilteredStringsList = @()

    if ( $null -eq $Filter ) {
        $null
    }

    elseif ( $Filter.Count -gt 0 ) {

        foreach ( $Param in $Filter.GetEnumerator() ) {

            foreach ( $Val in $Param.Value ) {

                if ( $Val.getType().Name -eq [string] ) {

                    $FilteredStringsList += "`$_.$($Param.Name) -eq '$Val'"
                }
                else {

                    $FilteredStringsList += "`$_.$($Param.Name) -eq $Val"
                }
            }
        }
        $WhereString = $FilteredStringsList -Join " -and "
        $WhereBlock = [scriptblock]::Create( $WhereString )
        $WhereBlock
    }
    else {
        $null
    }
}

Export-ModuleMember -Function 'Get-GsxEventLogV1'