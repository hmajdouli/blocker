#Requires -Version 4

# Set-StrictMode generates a terminating error when the content of an expression, script, or script block violates basic best-practice coding rules.
Set-StrictMode -Version 2.0

function Get-GsxMemoryPerfCounterV1 {
	<#
		.SYNOPSIS
		This command will return memory performance counters.

		.DESCRIPTION
		This command will return memory performance counters.
		You can find below some information regarding the statistics retrieved:
		- Memory used in MB
        - Total memory in MB
        - Memory used in %

		.LINK
		More information about the Win32_OperatingSystem WMI class can be found here:
		https://docs.microsoft.com/en-us/windows/desktop/cimwin32prov/win32-operatingsystem

		.PARAMETER PowerShellLocal
        Type: [Bool]
        Default value: $false
        Description: Defines whether we use PowerShell locally or in a PSSession.

		.EXAMPLE
		Running the Get-GsxMemoryPerfCounterV1 command

			PS> Get-GsxMemoryPerfCounterV1

		.OUTPUTS
		Here is an example of the output:

			| Name           | Value                                                                                                |
			| -------------- | ---------------------------------------------------------------------------------------------------- |
			| CommandCode    | 0                                                                                                    |
			| CommandMessage | Memory performance counter(s) successfully retrieved                                                 |
			| MemoryCounters | [ { "MemoryUsedInMegaBytes": 8000, "MemoryTotalInMegaBytes": 10000, "MemoryUsedInpercentage": 80 } ] |

		The output from this command will be an object that has the following properties available:

			| Properties     | Type   |
			| -------------- | ------ |
			| CommandCode    | Int    |
			| CommandMessage | String |
			| MemoryCounters | String |

		.NOTES
        Command codes and messages

			| CommandCode | CommandMessage                                       | MemoryCounters                               | Description                                                               |
			| ----------- | ---------------------------------------------------- | -------------------------------------------- | ------------------------------------------------------------------------- |
			| 0           | Memory performance counter(s) successfully retrieved | Memory performance counter(s) as JSON string | Command successful with memory performance counter(s) counters retrieved. |
			| 1           | Exception message                                    | -                                            | An issue occurred while retrieving the memory performance counters.       |
    #>

    [OutputType([psobject])]
    [cmdletbinding()]
	Param(
		[bool] $PowerShellLocal = $false
	)

    $Output = [ordered]@{
		CommandCode    = $null
		CommandMessage = ""
		MemoryCounters   = ""
    }

	$OldErrorActionPreference = $ErrorActionPreference
	$ErrorActionPreference = 'Stop'

     # Converting the sizes in GigaBytes
     $TotalMemorySizeInMegaByte  = @{ Label = "MemoryTotalInMegaBytes";  Expression = { [double][System.Math]::Round(($_.TotalVisibleMemorySize / 1000), 12) } }
     $UsedMemoryInMegaByte       = @{ Label = "MemoryUsedInMegaBytes";   Expression = { [double][System.Math]::Round((($_.TotalVisibleMemorySize / 1000) - ($_.FreePhysicalMemory / 1000)), 12) } }
     $UsedMemoryInPercentage             = @{ Label = "MemoryUsedInPercentage";  Expression = { [double][System.Math]::Round((((($_.TotalVisibleMemorySize / 1000) - ($_.FreePhysicalMemory / 1000)) / ($_.TotalVisibleMemorySize / 1000) ) * 100), 12) } }

    $PropertiesList = @(
		$TotalMemorySizeInMegaByte
        $UsedMemoryInMegaByte
        $UsedMemoryInPercentage
    )

    try {

		$CimInstanceParameters = @{ ClassName = 'Win32_OperatingSystem' }

		$CommandParameters = @{
			ScriptBlock = {param ($CimInstanceParameters) (Get-CimInstance @CimInstanceParameters)}
			ArgumentList = $CimInstanceParameters
		}

		if (!$PowerShellLocal) {
			$CommandParameters.Session = Get-PSSession
		}

        Write-Verbose "Retrieving memory performance counters..."
		$CimInstanceResult = Invoke-Command @CommandParameters

        $MemoryCounters = $CimInstanceResult | Select-Object $PropertiesList
        $Output.MemoryCounters = (@($MemoryCounters) | ConvertTo-Json -Depth 5 -Compress)

        Add-GsxOutputCodeAndMessage -Output $Output -Code 0 -Message "Memory performance counter(s) successfully retrieved"
    }
    catch {
        $ErrorMessage = "An exception occurred: $($_.Exception.Message)"
		Write-Warning $ErrorMessage
		Add-GsxOutputCodeAndMessage -Output $Output -Code 1 -Message $ErrorMessage
    }

    $ErrorActionPreference = $OldErrorActionPreference
    $Output

}

function Add-GsxOutputCodeAndMessage {
    param(
        [Parameter( Mandatory = $true )] [System.Collections.Specialized.OrderedDictionary] $Output,
        [Parameter( Mandatory = $true )] [int] $Code,
        [Parameter( Mandatory = $true )] [string[]] $Message
    )
    $Output.CommandCode = $Code
    $Output.CommandMessage = ($Message | Select-Object -Unique) -join "`n"
}


Export-ModuleMember -Function 'Get-GsxMemoryPerfCounterV1'