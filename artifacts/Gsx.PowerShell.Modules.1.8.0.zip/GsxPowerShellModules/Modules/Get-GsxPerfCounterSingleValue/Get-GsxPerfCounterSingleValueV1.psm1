#Requires -Version 4

	# Set-StrictMode generates a terminating error when the content of an expression, script, or script block violates basic best-practice coding rules.
	Set-StrictMode -Version 2.0

	function Get-GsxPerfCounterSingleValueV1 {
		<#
			.SYNOPSIS
			This command will return performance counter data.

			.DESCRIPTION
			This command will return performance counter data.
			In case of multiple values found in the counter, we return the average of those values.

			.LINK
			More information about the Get-Counter command can be found here:
			https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.diagnostics/get-counter?view=powershell-5.1

			.PARAMETER Counter
			Type: [String]
			Description: Specifies, as a string, data from the specified performance counters. Enter one counter path.

			.PARAMETER SampleInterval
			Type: [Int32]
			Default value: 1
			Description: Specifies the time between samples in seconds. The minimum value and the default value are 1 second.

			.PARAMETER PowerShellLocal
			Type: [Bool]
			Default value: $false
			Description: Defines whether we use PowerShell locally or in a PSSession.

			.EXAMPLE
			Running the Get-GsxPerfCounterSingleValueV1 command

				PS> Get-GsxPerfCounterSingleValueV1 -Counter '\processor(_total)\% processor time' -SampleInterval 2

			.OUTPUTS
			Here is an example of the output:

				| Name           | Value                                                                                                   |
				| -------------- | ------------------------------------------------------------------------------------------------------- |
				| CommandCode    | 0                                                                                                       |
				| CommandMessage | Performance counter(s) successfully retrieved                                                                   |
				| PerfCounter    | [ { "\computer\memory\available mbytes":9.1458956 } ] |

			The output from this command will be an object that has the following properties available:

				| Properties     | Type   |
				| -------------- | ------ |
				| CommandCode    | Int    |
				| CommandMessage | String |
				| PerfCounter    | String |

			.NOTES
			Command codes and messages

				| CommandCode | CommandMessage                                | PerfCounter value                     | Description                                                  |
				| ----------- | --------------------------------------------- | ------------------------------------- | ------------------------------------------------------------ |
				| 0           | Performance counter(s) successfully retrieved | Performance counter(s) as JSON string | Command successful with performance counters retrieved.      |
				| 1           | Exception message                             | -                                     | An issue occurred while retrieving the performance counters. |

		#>

		[OutputType([psobject])]
		[cmdletbinding()]
		Param(
			[string] $Counter,
			[int]    $SampleInterval = 1,
			[bool]   $PowerShellLocal = $false
		)

		$Output = [ordered]@{
			CommandCode    = $null
			CommandMessage = ""
			PerfCounters   = ""
		}

		# Storing current error action preference
		$OldErrorActionPreference = $ErrorActionPreference
		$ErrorActionPreference = 'Stop'

		try {

			$GetCounterParameters = @{
				Counter        = $Counter
				SampleInterval = $SampleInterval }

			$CommandParameters = @{
				ScriptBlock = { param ($GetCounterParameters)

					$CountersToReturn = (Get-Counter @GetCounterParameters | Select-Object -ExpandProperty CounterSamples)

					return $CountersToReturn }
				ArgumentList = $GetCounterParameters
			}

			if (!$PowerShellLocal) {
				$CommandParameters.Session = Get-PSSession
			}

			Write-Verbose "Retrieving performance counters..."
			$PerfCountersObject = Invoke-Command @CommandParameters -ErrorAction SilentlyContinue

			$CookedValue = $PerfCountersObject.CookedValue

			if ($PerfCountersObject -is [array]) {
				$CookedValue = ($PerfCountersObject.CookedValue | Measure-Object -Average).Average
			}

			$Output.PerfCounter = $CookedValue

			Add-GsxOutputCodeAndMessage -Output $Output -Code 0 -Message "Performance counter successfully retrieved"
		}
		catch {
			$ErrorMessage = 'An exception occurred: ' + $_.Exception.Message
			if($Counter) { $ErrorMessage += "`nCounter: $Counter" }
			Write-Warning $ErrorMessage
			Add-GsxOutputCodeAndMessage -Output $Output -Code 1 -Message $ErrorMessage
		}

		$ErrorActionPreference = $OldErrorActionPreference

		$Output
	}

	function Add-GsxOutputCodeAndMessage {
		param(
			[Parameter( Mandatory = $true )] [System.Collections.Specialized.OrderedDictionary] $Output,
			[Parameter( Mandatory = $true )] [int] $Code,
			[Parameter( Mandatory = $true )] [string[]] $Message
		)
		$Output.CommandCode = $Code
		$Output.CommandMessage = ($Message | Select-Object -Unique) -join "`n"
	}

	Export-ModuleMember -Function 'Get-GsxPerfCounterSingleValueV1'