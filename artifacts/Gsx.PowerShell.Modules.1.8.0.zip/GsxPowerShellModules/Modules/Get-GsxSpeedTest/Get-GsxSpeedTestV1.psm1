#Requires -Version 4

# Set-StrictMode generates a terminating error when the content of an expression, script, or script block violates basic best-practice coding rules.
Set-StrictMode -Version 2.0

function Get-GsxSpeedTestV1 {
    <#
		.SYNOPSIS
		This command will return the UDP and TCP bandwidth using iPerf3 open source tool.

		.DESCRIPTION
		This command will return the UDP and TCP bandwidth using iPerf3 open source tool.

		.LINK
		More information about the iPerf tool can be found here:
		https://iperf.fr/

		.PARAMETER Hostname
		Type: [String]
		Description: Defines the target host where an iPerf is running.

		.PARAMETER PortRange
		Type: [Int]
		Description: Defines the number of ports to scan, starting from 5201 (e.g 9 will scan from port 5201 to 5210).

		.PARAMETER Iteration
		Type: [Int]
		Description: Defines the number of times that we will scan the ports.

		.PARAMETER ParallelStreams
        Type: [Int]
        Default value: 10
		Description: Defines the number of simultaneous connections to make to the server.

		.EXAMPLE
		Running the Get-GsxSpeedTestV1 command

			PS> Get-GsxSpeedTestV1

		.OUTPUTS
		Here is an example of the output:

            | Name             | Value                                                                          |
            | ---------------- | ------------------------------------------------------------------------------ |
            | CommandCode      | 0                                                                              |
            | CommandMessage   | Speed test metric(s) successfully retrieved                                    |
            | SpeedTestMetrics | [ { "UDPSeconds":20.000369, "UDPPackets":384, "UDPJitterInMs":26.300000... } ] |

		The output from this command will be an object that has the following properties available:

            | Properties       | Type   |
            | ---------------- | ------ |
            | CommandCode      | Int    |
            | CommandMessage   | String |
            | SpeedTestMetrics | String |

		.NOTES
		Command codes and messages

            | CommandCode | CommandMessage                                                                                     | SpeedTestMetrics value            | Description                                                               |
            | ----------- | -------------------------------------------------------------------------------------------------- | --------------------------------- | ------------------------------------------------------------------------- |
            | 0           | Speed test metric(s) successfully retrieved                                                        | Speed test metrics as JSON string | Command successful with speed test metric(s) retrieved.                   |
            | 1           | UDP test looped <iteration> time(s) from port <start_port> to <end_port> with no success.          | -                                 | An issue occurred while retrieving the UDP speed test metric(s).          |
            | 2           | TCP download test looped <iteration> time(s) from port <start_port> to <end_port> with no success. | -                                 | An issue occurred while retrieving the TCP download speed test metric(s). |
            | 4           | TCP upload test looped <iteration> time(s) from port <start_port> to <end_port> with no success.   | -                                 | An issue occurred while retrieving the TCP upload speed test metric(s).   |
            | 7           | All speed tests failed.                                                                            | -                                 | An issue occurred while retrieving the speed test metric(s).              |
	#>

    [OutputType([psobject])]
    [cmdletbinding()]
    Param(
        $Hostname,
        $PortRange = 9,
        $Iteration = 10,
        $ParallelStreams = 10
    )

    begin {

        $Output = [ordered]@{
            CommandCode      = 0
            CommandMessage   = ""
            SpeedTestMetrics = ""
        }

        $CommandCode = 0

        $SpeedTestMetrics = @{}
        $CommandMessageList = @()

        $MainFolder = (Get-Item -Path $PSScriptRoot).Parent.Parent.Parent.FullName
        $IPerfPath = Join-Path -Path $MainFolder -ChildPath "iperf3\iperf3.exe"

        #region Port
        $StartPort = 5201
        $EndPort = $StartPort + $PortRange
        $Ports = $StartPort..$EndPort
        $MaximumLoop = $Iteration * $Ports.Length
        $MaximumLoopMessage = "test looped $Iteration time(s) on the host '$Hostname' from port $StartPort to $EndPort with no success."
        #endregion Port
    }

    process {

        #region CheckIPerfExists
        if ( !(Test-Path $IPerfPath) ) {
            Add-GsxOutputCodeAndMessage -Output $Output -Code 7 -Message "Command failed because iperf3.exe is not found in '$IPerfPath'"
            return
        }
        #endregion CheckIPerfExists

        #region TestUDP
        $PortIndex = 0
        $UDPLoop = 1
        $UDPMessageList = @()
        try {

            do {
                $UDPPort = $Ports[$PortIndex]
                $UDPParameters = "-c $Hostname -p $UDPPort -u -b 1258291 -t 20 -J"

                if ($null -eq $UDPPort) {
                    $PortIndex = 0
                    $UDPPort = $Ports[$PortIndex]
                }

                if ($UDPLoop -gt $MaximumLoop) {
                    $Message = "UDP $MaximumLoopMessage"
                    Write-Warning $Message
                    $UDPMessageList = ,$Message + $UDPMessageList
                    $CommandCode += 1
                    break
                }
                else {
                    Write-Verbose "UDP test on port $UDPPort, Loop $UDPLoop"
                    $UDP = Get-GsxSpeedTestMetric -IPerfPath $IPerfPath -Parameters $UDPParameters
                    $UDPMetrics = $UDP.Metrics
                    $UDPError   = $UDP.Error

                    if ($UDPError) { $UDPMessageList += "UDP test on port $UDPPort, Loop $UDPLoop, Error: $UDPError" }
                }

                $PortIndex++
                $UDPLoop++
            }
            until ( (($null -ne $UDPMetrics) -and ($null -eq $UDPError)) )

        }
        catch {
            $CommandMessageList += $_.Exception.Message
            $CommandCode += 1
        }

        $UDPMessageString = $UDPMessageList -join "`n"
        #endregion TestUDP

        #region TestTCPDownload
        $PortIndex = 0
        $TCPDownloadLoop = 1
        $TCPDownloadMessageList = @()
        try {

            do {
                $TCPDownloadPort = $Ports[$PortIndex]
                $TCPDownloadParameters = "-c $Hostname -p $TCPDownloadPort -P $ParallelStreams -J"

                if ($null -eq $TCPDownloadPort) {
                    $PortIndex = 0
                    $TCPDownloadPort = $Ports[$PortIndex]
                }

                if ($TCPDownloadLoop -gt $MaximumLoop) {
                    $Message = "TCP download $MaximumLoopMessage"
                    Write-Warning $Message
                    $TCPDownloadMessageList = ,$Message + $TCPDownloadMessageList
                    $CommandCode += 2
                    break
                }
                else {
                    Write-Verbose "TCP download test on port $TCPDownloadPort, Loop $TCPDownloadLoop"
                    $TCPDownload = Get-GsxSpeedTestMetric -IPerfPath $IPerfPath -Parameters $TCPDownloadParameters
                    $TCPDownloadMetrics = $TCPDownload.Metrics
                    $TCPDownloadError   = $TCPDownload.Error

                    if ($TCPDownloadError) { $TCPDownloadMessageList += "TCP download test on port $TCPDownloadPort, Loop $TCPDownloadLoop, Error: $TCPDownloadError" }

                }

                $PortIndex++
                $TCPDownloadLoop++
            }
            until ( (($null -ne $TCPDownloadMetrics) -and ($null -eq $TCPDownloadError)) )

        }
        catch {
            $CommandMessageList += $_.Exception.Message
            $CommandCode += 2
        }

        $TCPDownloadMessageString = $TCPDownloadMessageList -join "`n"
        #endregion TestTCPDownload

        #region TestTCPUpload
        $PortIndex = 0
        $TCPUploadLoop = 1
        $TCPUploadMessageList = @()
        try {

            do {
                $TCPUploadPort = $Ports[$PortIndex]
                $TCPUploadParameters = "-c $Hostname -p $TCPUploadPort -R -P $ParallelStreams -J"

                if ($null -eq $TCPUploadPort) {
                    $PortIndex = 0
                    $TCPUploadPort = $Ports[$PortIndex]
                }

                if ($TCPUploadLoop -gt $MaximumLoop) {
                    $Message = "TCP upload $MaximumLoopMessage"
                    Write-Warning $Message
                    $TCPUploadMessageList = ,$Message + $TCPUploadMessageList
                    $CommandCode += 4
                    break
                }
                else {
                    Write-Verbose "TCP upload test on port $TCPUploadPort, Loop $TCPUploadLoop"
                    $TCPUpload = Get-GsxSpeedTestMetric -IPerfPath $IPerfPath -Parameters $TCPUploadParameters
                    $TCPUploadMetrics = $TCPUpload.Metrics
                    $TCPUploadError   = $TCPUpload.Error

                    if ($TCPUploadError) { $TCPUploadMessageList += "TCP upload test on port $TCPUploadPort, Loop $TCPUploadLoop, Error: $TCPUploadError" }
                }

                $PortIndex++
                $TCPUploadLoop++
            }
            until ( (($null -ne $TCPUploadMetrics) -and ($null -eq $TCPUploadError)) )
        }
        catch {
            $CommandMessageList += $_.Exception.Message
            $CommandCode += 4
        }

        $TCPUploadMessageString = $TCPUploadMessageList -join "`n"
        #endregion TestTCPUpload

        #region InsertResults
        if ( (($null -ne $UDPMetrics) -and ($null -eq $UDPError)) ) {
            $SpeedTestMetrics.UDPJitterInMs     = $UDPMetrics.end.sum.jitter_ms
            $SpeedTestMetrics.UDPSeconds        = $UDPMetrics.end.sum.seconds
            $SpeedTestMetrics.UDPMbitsPerSecond = ($UDPMetrics.end.sum.bits_per_second / 1000000)
            $SpeedTestMetrics.UDPLostPercent    = $UDPMetrics.end.sum.lost_percent
            $SpeedTestMetrics.UDPOutOfOrder     = $UDPMetrics.end.streams.udp.out_of_order
            $SpeedTestMetrics.UDPPackets        = $UDPMetrics.end.streams.udp.packets
            $SpeedTestMetrics.UDPLostPackets    = $UDPMetrics.end.streams.udp.lost_packets

            if ($SpeedTestMetrics.UDPPackets -gt 0) {
                $PacketOutOfOrder = $UDPMetrics.end.streams.udp.out_of_order / $SpeedTestMetrics.UDPPackets
                $SpeedTestMetrics.UDPPacketOutOfOrder = $PacketOutOfOrder
            }
            else {
                $SpeedTestMetrics.UDPPacketOutOfOrder = 'Count of packets was zero, therefore calculation skipped as it would have resulted in div by zero.'
            }
        }

        if ( (($null -ne $TCPDownloadMetrics) -and ($null -eq $TCPDownloadError)) ) {
            $SpeedTestMetrics.TCPDownloadSentInMbitsPerSecond = ($TCPDownloadMetrics.end.sum_sent.bits_per_second / 1000000)
        }

        if ( (($null -ne $TCPUploadMetrics) -and ($null -eq $TCPUploadError)) ) {
            $SpeedTestMetrics.TCPUploadSentInMbitsPerSecond = ($TCPUploadMetrics.end.sum_sent.bits_per_second / 1000000)
        }
        #endregion InsertResults

        #region PrepareOutput
        $CommandMessageList += $UDPMessageString, $TCPDownloadMessageString, $TCPUploadMessageString

        if ($CommandCode -lt 7) {

            if ($CommandCode -eq 0) {
                $CommandMessageList = 'Speed test metric(s) successfully retrieved'
            }
            else {
                $CommandMessageList = ,'Some speed test(s) failed' + $CommandMessageList
            }

            $SpeedTestMetrics.Hostname = $Hostname
            $Output.SpeedTestMetrics = $SpeedTestMetrics | ConvertTo-Json
        }
        else {
            $CommandMessageList = ,'All speed tests failed' + $CommandMessageList
        }

        Add-GsxOutputCodeAndMessage -Output $Output -Code $CommandCode -Message $CommandMessageList
        #endregion PrepareOutput
    }

    end {
        return ($Output)
    }
}

function Get-GsxSpeedTestMetric {
    param(
        [string]$IPerfPath,
        [string]$Parameters
    )

    $Output = @{
        Metrics = $null
        Error = $null
    }

    try {
        $ParametersAsList = $Parameters -split ' '
        $Metrics = Invoke-Command -ScriptBlock { & $IPerfPath $ParametersAsList }
        $MetricsAsObject = $Metrics | ConvertFrom-Json
        $ErrorMessage = if ($MetricsAsObject.psobject.Properties.name.Contains('error')) { $MetricsAsObject.error } else { $null }

        $Output.Metrics = $MetricsAsObject
        $Output.Error   = $ErrorMessage
    }
    catch {
        if ($Metrics) {
            $Output.Error = $Metrics
        }
        else {
            $Output.Error = $_.Exception.Message
        }
    }

    $Output
}

function Add-GsxOutputCodeAndMessage {
    param(
        [Parameter( Mandatory = $true )] [System.Collections.Specialized.OrderedDictionary] $Output,
        [Parameter( Mandatory = $true )] [int] $Code,
        [Parameter( Mandatory = $true )] $Message
    )
    $Output.CommandCode = $Code
    $Output.CommandMessage = ($Message | Where-Object { $_ } | Select-Object -Unique) -join "`n"
}

Export-ModuleMember -Function 'Get-GsxSpeedTestV1'