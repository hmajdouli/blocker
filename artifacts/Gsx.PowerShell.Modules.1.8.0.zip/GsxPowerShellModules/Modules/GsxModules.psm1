$Modules = (Get-ChildItem -Path $PSScriptRoot -Directory) | Get-ChildItem -File -Filter *.psm1

foreach ($Module in $Modules) {
    Import-Module $Module.FullName -Force
}

$Commands = $Modules.BaseName

Export-ModuleMember -Function $Commands