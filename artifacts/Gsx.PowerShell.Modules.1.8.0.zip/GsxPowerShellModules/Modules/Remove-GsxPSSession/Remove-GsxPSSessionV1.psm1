#Requires -Version 4

# Set-StrictMode generates a terminating error when the content of an expression, script, or script block violates basic best-practice coding rules.
Set-StrictMode -Version 2.0

function Remove-GsxPSSessionV1 {
    <#
		.SYNOPSIS
		This command will closes one or more Windows PowerShell sessions (PSSessions).

		.DESCRIPTION
        This command will closes one or more Windows PowerShell sessions (PSSessions).

        .LINK
        More information about the Remove-PSSession command:
        https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.core/remove-pssession?view=powershell-4.0

		.PARAMETER PowerShellLocal
        Type: [Bool]
        Default value: $false
        Description: Defines whether we use PowerShell locally or in a PSSession.

		.EXAMPLE
		Running the Remove-GsxPSSession command

            PS> Remove-GsxPSSession

        .OUTPUTS
        Here is an example of the output:

            | Name           | Value                             |
            | -------------- | --------------------------------- |
            | CommandCode    | 0                                 |
            | CommandMessage | PSSession(s) successfully removed |

        The output from this command will be an object that has the following properties available:

            | Properties     | Type   |
            | -------------- | ------ |
            | CommandCode    | Int    |
            | CommandMessage | String |

		.NOTES
        Command codes and messages

            | CommandCode | CommandMessage                                          | Description                                                      |
            | ----------- | ------------------------------------------------------- | ---------------------------------------------------------------- |
            | 0           | PSSession(s) successfully removed or no PSSession found | One or more PSSession successfully removed or no PSSession found |
            | 1           | No PSSession to remove when Local PowerShell is defined | No PSSession to remove when Local PowerShell is defined          |
            | 2           | An exception occurred while removing the PSSession      | -                                                                |
	#>

    [CmdletBinding(SupportsShouldProcess)]
    [OutputType([object])]
    Param(
        [bool] $PowerShellLocal = $false
    )

    begin {

        [Array] $CommandMessageList = @()
        [int]   $CommandCode        = 0

        $Output = [ordered]@{
            CommandCode    = $CommandCode
            CommandMessage = ""
            SessionRemoved = $true
        }
    }

    process {
        # Storing current error action preference
        $OldErrorActionPreference = $ErrorActionPreference
        $ErrorActionPreference = 'Stop'

        try {

            if ($PowerShellLocal) {
                $Message = 'No PSSession to remove when Local PowerShell is defined'
                Write-Verbose $Message
                $CommandMessageList = $Message
                $CommandCode = 1
            }
            else {

                $SessionsToBeRemoved = Get-PSSession

                if ($SessionsToBeRemoved) {

                    if ( $PSCmdlet.ShouldProcess($SessionsToBeRemoved) ) {
                        Remove-PSSession -Session $SessionsToBeRemoved
                        $Message = 'PSSession(s) successfully removed.'
                        Write-Verbose $Message
                        $CommandMessageList = $Message
                    }
                }
                else {
                    $Message = 'No PSSession found'
                    Write-Verbose $Message
                    $CommandMessageList = $Message
                }
            }
        }
        catch {
            Write-Warning "An exception occurred while removing the remote session:`n $($_.Exception.Message)"
            $CommandMessageList = ,((@("An exception occurred while removing the remote session:", $_.Exception.Message) |
            Select-Object -Unique) -join "`n") + $CommandMessageList
            $CommandCode = 2
            $Output.SessionRemoved = $false
        }

        Add-GsxOutputCodeAndMessage -Output $Output -Code $CommandCode -Message $CommandMessageList

        $ErrorActionPreference = $OldErrorActionPreference
    }
    end {
        $Output
    }
}

function Add-GsxOutputCodeAndMessage {
    param(
        [Parameter( Mandatory = $true )] [System.Collections.Specialized.OrderedDictionary] $Output,
        [Parameter( Mandatory = $true )] [int] $Code,
        [Parameter( Mandatory = $true )] [string[]] $Message
    )

    $Output.CommandCode = $Code
    $Output.CommandMessage = ($Message | Select-Object -Unique) -join "`n`n"
}

Export-ModuleMember -Function 'Remove-GsxPSSessionV1'