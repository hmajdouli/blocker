<#
    .SYNOPSIS
    This command will create a persistent connection to a local or remote computer.

    .DESCRIPTION
    This command will create a persistent connection to a local or remote computer.

    .LINK
    More information about the New-PSSession command:
    https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.core/new-pssession?view=powershell-4.0

    More information about the New-PSSessionOption command:
    https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.core/new-pssessionoption?view=powershell-4.0

    .PARAMETER ServerFQDN
    Type: [String]
    Description: Specifies an Exchange server FQDN.

    .PARAMETER UseSSL
        Type: [Bool]
        Default value: $false
        Description: Indicates that this cmdlet uses the SSL protocol to establish a connection to the remote computer.

    .PARAMETER Port
        Type: [Int32]
        Description: Specifies the network port on the remote computer that is used for this connection.
        The default ports are 5985, which is the WinRM port for HTTP, and 5986, which is the WinRM port for HTTPS.

    .PARAMETER Username
        Type: [String]
        Description: Specifies the user account.

    .PARAMETER Password
        Type: [String]
        Description: Specifies the user account password.

    .PARAMETER Authentication
        Type: [String]
        Default value: 'Negotiate'
        Values accepted:'Basic', 'Negotiate', 'Kerberos'
        Description: Indicates the authentication mechanism used to establish a connection to the remote computer.
    
    .PARAMETER ApplicationName
        Type: [String]
        Default value: 'wsman'
        Description: Specifies the application name segment of the connection URI. 

    .PARAMETER ConfigurationName
        Type: [String]
        Default value: 'Microsoft.PowerShell'
        Description: Specifies the session configuration that is used for the new PSSession. 

    .PARAMETER PowerShellLocal
        Type: [Bool]
        Default value: $false
        Description: Defines whether we use PowerShell locally or in a PSSession.

    .EXAMPLE
    Running the New-GsxPSSession.ps1 script file to create a remote PSSession

        PS> & C:\SomePath\New-GsxPSSession.ps1 -ServerFQDN $ServerFQDN -Username $Username -Password $Password -PowershellLocal 'false'

    .OUTPUTS

    Here is an example of the output:

        | PropertyId  | Index  | Value       | CommandCode | CommandMessage                                   |
        | ----------- | ------ | ------------|-------------|------------------------------------------------- |
        | 1           | null   | true        | 0           |                                                  |
        | 2           | null   | Negociate   | 0           |                                                  |
        | 3           | null   | 1.452       | 0           |                                                  |


    .NOTES
    Command codes and messages

        | CommandCode | CommandMessage                                                                                                      | Description                                                                                                                                            |
        | ----------- | ------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
        | 0           |                                                                                                                     | Exchange remote session successfully created using the authentication specified in the command message                                                 |
        | 1           | No Exchange PSSession to create when Local PowerShell is defined                                                    | No Exchange PSSession is created when the PowerShellLocal parameter is set to 'true'                                                                   |
        | 2           | An exception occurred while creating the Exchange PSSession using '<authentication>' authentication                 | Attempt to create the Exchange remote session failed with the authentication mechanism (Kerberos, Negotiate or Basic) |

#>

param(
    [string] $ServerFQDN,
    [string] $Username,
    [string] $Password,
    [Nullable[bool]] $UseSSL = $false,
    [Nullable[Int32]] $Port,
    [string] $Authentication,
    [string] $ApplicationName ,
    [string] $ConfigurationName,
    [Nullable[bool]] $PowerShellLocal = $false
)
if ([string]::IsNullOrEmpty($Authentication)) {
	$Authentication = "Negotiate"
}
if ([string]::IsNullOrEmpty($ApplicationName)) {
	$ApplicationName = "wsman"
}
if ([string]::IsNullOrEmpty($ConfigurationName)) {
	$ConfigurationName = "Microsoft.PowerShell"
}
try {
	$Output = New-Object Gsx.Robot.PSModel.PSOutput
} catch {
	throw 'Command failed because the GSX DLL is not loaded'
}

[string] $CommandMessage = ''
[int]   $CommandCode = 2
[bool]  $Success = $false

if ($PowerShellLocal) {
     $CommandMessageList = 'No Exchange PSSession to create when Local PowerShell is defined'
	 $CommandCode = 1
}
else {
    # Storing current error action preference
    $OldErrorActionPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Stop'
    try {

        $MandatoryParameters = @{
            ServerFQDN = $ServerFQDN
            Username   = $Username
            Password   = $Password
        }

        if ($MandatoryParameters.ContainsValue($null) -or $MandatoryParameters.ContainsValue('')) {
            $ParametersNotSet = (($MandatoryParameters.GetEnumerator()) | Where-Object { ($null -eq $_.Value) -or ('' -eq $_.Value) }).Name -join ', '
            throw "You must supply a value for the following parameter(s): $ParametersNotSet"
        }

        # Server credentials
        $Credentials = New-Object System.Management.Automation.PSCredential ($Username, (ConvertTo-SecureString $Password -AsPlainText -Force))
        
        $Transport =  if ($UseSSL) {'https'} Else {'http'};
        if ($Port -eq $null) {
	        $Port = if ($UseSSL) {5986} Else {5985};
        }

        $EndPointUri = "$($Transport)://$($ServerFQDN):$($Port)/$($ApplicationName)/"

        $PSSessionConfig = [ordered]@{
            Credential        = $Credentials
            ConfigurationName = $ConfigurationName
            ConnectionUri     = $EndPointUri
            Authentication    = $Authentication
        }

        $PSSessionOptions = New-PSSessionOption -Culture 'en'
        $PSSessionOptions.SkipCACheck = $true
        $PSSessionOptions.SkipCNCheck = $true
        $PSSessionOptions.SkipRevocationCheck = $true

        $Stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        $null = New-PSSession @PSSessionConfig -SessionOption @PSSessionOptions -AllowRedirection
        $Stopwatch.Stop()
        $ConnectionTimeInMilliseconds = [System.Math]::Floor($Stopwatch.Elapsed.TotalMilliseconds)
       
        Write-Verbose "Exchange PSSession successfully created for '$ServerFQDN' using '$Authentication' authentication"

        $CommandCode = 0
        $Success = $true
    }
    catch {
        Write-Warning "An exception occurred while creating the PSSession: $($_.Exception.Message)"
        $CommandMessage = $_.Exception.Message
	}
    $ErrorActionPreference = $OldErrorActionPreference
}
$Output.AddResult(1, $null, $Success, $CommandCode, $CommandMessage)
$Output.AddResult(2, $null, $Authentication, $CommandCode, $CommandMessage)
$Output.AddResult(3, $null, $ConnectionTimeInMilliseconds, $CommandCode, $CommandMessage)

return $Output