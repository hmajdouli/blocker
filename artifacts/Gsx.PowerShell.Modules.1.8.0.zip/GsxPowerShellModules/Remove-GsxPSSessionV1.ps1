param (
    [bool] $PowerShellLocal = $false
)

$Output = New-Object Gsx.Robot.PSModel.PSOutput

# Import Module
Import-Module "$pwd\GsxPowerShellModules\Modules\GsxModules.psm1" -Force

# Getting PSSession
$PSSessionsOutput = Remove-GsxPSSessionV1 -PowerShellLocal $PowerShellLocal
$CommandCode = $PSSessionsOutput.CommandCode
$CommandMessage = $PSSessionsOutput.CommandMessage
$SessionRemoved = $PSSessionsOutput.SessionRemoved

# This object with Property ID set to -1 is the status of the command
$Output.AddResult(1, $null, $SessionRemoved, $CommandCode, $CommandMessage)

# We will exit the PowerShell by returning this exact object
Return($Output)